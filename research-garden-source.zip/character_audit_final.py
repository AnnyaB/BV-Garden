from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
from hashlib import sha256
import zipfile
D=Path(__file__).parent
out=Path('/mnt/data')
ids=['anya','bond','chimera','becky','damian','emile','ewen','henry','franky','yuri','sylvia','fiona','martha','melinda','donovan','demetrius','camilla','shopkeeper','yor','loid']
W,H=1070,940
sheet=Image.new('RGB',(W,H),(241,239,229))
d=ImageDraw.Draw(sheet)
for i,c in enumerate(ids):
 img=Image.open(D/'assets'/f'{c}.png').convert('RGBA')
 # Subtle solid color backing proves real transparency and no stray white boxes
 x=(i%5)*212+10;y=(i//5)*232+8
 d.rounded_rectangle((x,y,x+195,y+218),radius=12,fill=(222,235,224),outline=(193,205,193),width=2)
 # enlarge slightly with nearest interpolation, while preserving actual source pixel PNG
 scale=min(1.25,166/max(1,img.height),178/max(1,img.width))
 shown=img.resize((round(img.width*scale),round(img.height*scale)),Image.Resampling.NEAREST)
 sheet.paste(shown,(x+(195-shown.width)//2,y+(178-shown.height)//2),shown)
 caption=f'{i+1:02}   {c.upper()}'
 d.text((x+14,y+189),caption,fill=(30,53,41))
p=out/'Research_Garden_Actual_20_Game_Sprites.png';sheet.save(p)
print('gallery',p,p.stat().st_size)
with zipfile.ZipFile(out/'The_Latent_Atlas_Research_Garden_GitHub.zip') as z:
 names=z.namelist()
 print('packed_assets',sum(n.startswith('assets/') and n.endswith('.png') for n in names))
 print('packed_meta',sorted(n for n in names if n.startswith('artwork_sources/')))
print('sha original',[(a,sha256((D/'assets'/f'{a}.png').read_bytes()).hexdigest()[:10]) for a in ['anya','bond','yor','loid','explorer']])
