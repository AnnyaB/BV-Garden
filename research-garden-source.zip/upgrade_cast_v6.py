"""Crop the 16 individually rendered, identifiable fan-art figures from the 4x4 sprite atlas.

Preserves the original lead-four sprites + explorer, and has no network calls.
The source atlas is included in `artwork_sources/` for editability/provenance.
"""
from PIL import Image, ImageFilter
from pathlib import Path
import numpy as np
import cv2

ROOT=Path(__file__).parent
SOURCE=ROOT/'artwork_sources'/'supporting_cast_4x4.png'
DEST=ROOT/'assets'
assert SOURCE.is_file(), SOURCE
src=Image.open(SOURCE).convert('RGB')
W,H=src.size
CAST=['becky','damian','chimera','emile','ewen','henry','franky','yuri',
      'sylvia','fiona','martha','melinda','donovan','demetrius','camilla','shopkeeper']

def extract(r,c):
    # 4x4 characters created for the game; each cell holds exactly one figure
    a=np.asarray(src.crop((round(W*c/4),round(H*r/4),round(W*(c+1)/4),round(H*(r+1)/4))))
    h,w=a.shape[:2]
    hi=a.max(axis=2).astype(np.int16)
    lo=a.min(axis=2).astype(np.int16)
    # Generated reference had a faux transparent checkerboard in the RGB data.
    # Its background is neutral light-gray (224–255). A conservative color mask
    # isolates shaded sprites while preserving skin, gold trim and white hair.
    foreground=((lo<196)|((hi-lo)>16)).astype(np.uint8)
    # Connect small intentional character details; the background stays empty.
    joined=cv2.morphologyEx(foreground,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5)))
    n,labels,stats,centroids=cv2.connectedComponentsWithStats(joined,8)
    scores=[]
    for i in range(1,n):
        x,y,cw,ch,area=stats[i]
        cx,cy=centroids[i]
        # The actual sprite sits around the horizontal middle of its cell.
        # Tiny fragments along a cell boundary belong to the adjacent row.
        if area>95 and .14*w<cx<.86*w and y<h-10:
            scores.append((area-abs(cx-w/2)*0.10,i))
    if not scores:raise RuntimeError('Could not isolate sprite')
    best=max(scores)[1]
    silhouette=(labels==best).astype(np.uint8)
    # Fill white clothing/eye/hair highlight interiors bounded by ink outlines.
    fill=cv2.floodFill((1-silhouette).copy(),None,(0,0),2)[1]
    silhouette=(fill!=2).astype(np.uint8)
    # Recover thin foreground edges within the chosen figure, but not checkerboard.
    silhouette=cv2.dilate(silhouette,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3)))
    # Kill isolated lines from the previous atlas row and tiny background specks.
    alpha=(silhouette*255).astype(np.uint8)
    yy,xx=np.where(alpha>0)
    if len(xx)==0:raise RuntimeError('Empty extraction')
    out=np.concatenate([a,alpha[:,:,None]],axis=2)
    top,left,bottom,right=yy.min(),xx.min(),yy.max(),xx.max()
    out=Image.fromarray(out).crop((max(0,left-2),max(0,top-2),min(w,right+3),min(h,bottom+3)))
    # webGL voxelization samples at small grid; keep detailed pixel art but
    # roughly match the size of original lead sprites and their proportions.
    maxw,maxh=114,150
    s=min(maxw/out.width,maxh/out.height)
    out=out.resize((max(1,round(out.width*s)),max(1,round(out.height*s))),Image.Resampling.LANCZOS)
    return out

for i,name in enumerate(CAST):
    result=extract(i//4,i%4)
    if name in ('sylvia','shopkeeper'):
        # The source art includes decorative checkerboard RGB behind part of her hat.
        # Remove these neutral light RGB pixels from the exported alpha sprite.
        a=np.array(result.convert('RGBA'))
        h,w=a.shape[:2]
        yy,xx=np.mgrid[:h,:w]
        rgb=a[:,:,:3].astype(int)
        stale_checker=((xx>=66) if name=='sylvia' else np.ones((h,w),dtype=bool))&(rgb.min(2)>=184)&((rgb.max(2)-rgb.min(2))<19)
        a[stale_checker,3]=0
        result=Image.fromarray(a)
    result.save(DEST/(name+'.png'))
    print(f'{name:12s}',result.size)
