from pathlib import Path
p=Path(__file__).parent
index=p/'index.html';s=index.read_text()
s=s.replace('<div class="progress-track"><span id="progress-fill"></span></div>','<div class="progress-track"><span id="progress-fill"></span></div><div id="rewardStrip" class="reward-strip" aria-live="polite"></div>')
s=s.replace('The white dog is stage 02; physical reasoning leads to the black-haired guide, and invention is the final stage.','The white dog is stage 02; the path ends at the theoretical intelligence frontier. Every chapter has four scored challenges, with Stella rewards and Tonitrus penalties.')
s=s.replace('A chapter unlock confirms one answered knowledge question, not mastery of the field.','A chapter unlock reflects a four-question conceptual assessment, not mastery of the field.')
s=s.replace('Twenty numbered','Twenty numbered')
s=s.replace('<script src="game.js" defer></script>','<script src="game.js" defer></script>\n<script src="quiz_bank.js" defer></script>\n<script src="quest_engine.js" defer></script>')
index.write_text(s)

game=p/'game.js';s=game.read_text()
s=s.replace("[...IDS,'explorer']","[...IDS,'explorer','stella','tonitrus','explorer_scholar']")
# 2D extra visual collectible right above the original character: original sprites unchanged
s=s.replace("if(state.current===ch.index){txt('✦',x,y-h-9+b,16,'#fff3c0');}","""if(typeof quest!=='undefined'){const badge=quest.stars[ch.index]?'stella':ch.index>state.current?'tonitrus':null;if(badge&&imgs[badge].complete&&imgs[badge].naturalWidth)ctx.drawImage(imgs[badge],x+22,y-h+2+b,21,22);}
 if(state.current===ch.index){txt('✦',x,y-h-9+b,16,'#fff3c0');}""")
game.write_text(s)

webgl=p/'garden3d.js';s=webgl.read_text()
s=s.replace("[...IDS,'explorer']","[...IDS,'explorer','stella','tonitrus']")
s=s.replace('if(!im.complete||!im.naturalWidth||texReady[id])return;','if(!im.complete||!im.naturalWidth)return;')
s=s.replace("for(const e of npcs){const ch=e.ch;if(voxelCast.ready&&!ch._you)continue;renderBillboard(ch.id,ch.place[0]+2.55,ch.place[1]-.8,ch._you?2.7:ch.id==='bond'?2.1:ch.id==='chimera'?1.9:2.6,ch._you?1.8:ch.id==='bond'?2.65:ch.id==='chimera'?1.45:1.75,ms);}","""for(const e of npcs){const ch=e.ch;if(voxelCast.ready&&!ch._you)continue;renderBillboard(ch.id,ch.place[0]+2.55,ch.place[1]-.8,ch._you?2.7:ch.id==='bond'?2.1:ch.id==='chimera'?1.9:2.6,ch._you?1.8:ch.id==='bond'?2.65:ch.id==='chimera'?1.45:1.75,ms);}
 // Volumetric garden + separately textured, depth-tested pixel award markers on each gated cottage.
 for(const ch of chapters){const badge=typeof quest==='undefined'?null:quest.stars[ch.index]?'stella':ch.index>state.current?'tonitrus':null;
 if(badge)renderBillboard(badge,ch.place[0]+1.65,ch.place[1]-1.9,1.05,.93,ms);}
""")
s=s.replace("el.classList.toggle('voxel-label-done',i<state.current);","""el.classList.toggle('voxel-label-done',i<state.current);
  if(typeof quest!=='undefined')el.style.borderColor=quest.stars[i]?'#d8ae57':i>state.current?'#9e5f65':'';""")
webgl.write_text(s)

build=p/'build.py';s=build.read_text()
s=s.replace("(root/'game.js').read_text()+'\\n'+(root/'garden3d.js').read_text()+'\\n'+(root/'research_labs.js').read_text()","(root/'game.js').read_text()+'\\n'+(root/'quiz_bank.js').read_text()+'\\n'+(root/'quest_engine.js').read_text()+'\\n'+(root/'garden3d.js').read_text()+'\\n'+(root/'research_labs.js').read_text()")
s=s.replace("js=js.replace('im.src=`assets/${id}.png`','im.src=INLINE_SPRITES[id]')","js=js.replace('im.src=`assets/${id}.png`','im.src=INLINE_SPRITES[id]')")
build.write_text(s)
print('Patched app HTML, fallback, WebGL and standalone build')
