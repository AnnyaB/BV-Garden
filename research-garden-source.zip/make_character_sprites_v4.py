"""Individualized pixel sprites for fifteen supporting SPY×FAMILY characters.

Original fan-art pixels drawn in PIL, NOT official frames or licensed sprites.
Main four characters and the user's avatar are deliberately left untouched.
Mr Chimera is drawn as a fantasy plush, rather than a generic NPC.
"""
from pathlib import Path
import importlib.util
from PIL import Image

root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('sprite_base_v3',root/'sprite_primitives.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
P=b.Pix; O=b.O; GOLD=b.GOLD; WHITE=b.WHITE

# Base pixels remain palette-limited for deliberately crisp retro 3D voxel rendering.
def outline(p,pts,col):
    p.p(pts,O);return p.p([(x+1 if x<38 else x-1,y+1 if y<60 else y-1) for x,y in pts],col)

def shoes(p,boots='#33303a'):
    for x in (25,46):
        p.r((x,83,x+7,101),'#3c3945');p.r((x+2,84,x+6,98),'#56505c')
        p.e((x-5,99,x+10,108),O);p.e((x-3,100,x+8,106),boots)
        p.r((x-2,104,x+7,105),'#82746b')

def adult_tunic(p,base,light,skin,skirt=False,coat=False):
    shoes(p)
    if skirt:
        p.p([(24,66),(53,66),(59,93),(18,93)],O)
        p.p([(26,67),(51,67),(55,90),(22,90)],base)
        p.p([(42,68),(48,68),(51,88),(44,90)],light)
    else:
        p.p([(24,58),(53,58),(56,85),(20,85)],O)
        p.p([(27,60),(51,60),(53,82),(23,82)],base)
        p.p([(26,61),(20,69),(19,81),(24,85),(31,64)],base)
        p.p([(50,60),(58,69),(58,81),(54,84),(46,64)],base)
        p.p([(43,60),(49,61),(49,79),(45,81)],light)
    for x in (18,54):p.r((x,80,x+6,86),skin)
    if coat:
        p.p([(27,70),(19,97),(30,97),(37,78)],base)
        p.p([(51,70),(58,97),(47,97),(42,78)],light)

def edenschool(p,girl,skin):
    shoes(p,'#27262b')
    if girl:
        p.p([(25,61),(50,61),(57,91),(19,91)],O)
        p.p([(27,62),(48,62),(53,88),(23,88)],'#302d37')
        for x in [24,30,36,42,48]:p.r((x,85,x+3,87),'#f1cf72')
        p.r((26,87,50,89),'#b79857')
        p.r((25,93,32,99),'#f5e1d3');p.r((46,93,52,99),'#f5e1d3')
    else:
        p.p([(24,60),(53,60),(55,86),(21,86)],O)
        p.p([(27,62),(50,62),(52,81),(25,81)],'#303137')
        p.r((26,84,51,87),'#e9ce82');p.r((27,82,50,84),'#d09d50')
    p.p([(22,62),(17,72),(18,81),(24,84),(29,64)],'#333039');p.p([(51,62),(57,71),(59,82),(53,85),(47,64)],'#333039')
    p.r((18,81,25,86),skin);p.r((53,81,59,86),skin)
    p.p([(31,60),(38,68),(45,60)],WHITE)
    p.p([(36,66),(40,66),(41,75),(37,76)],'#b8514b')
    p.r((25,76,52,78),'#dec079');p.r((33,63,35,65),'#ddbe83')
    p.r((46,70,51,76),'#823c45');p.r((48,70,50,73),'#f0ddab')

def detail_face(p,a,name):
    b.face(p,a)
    # Individualized expressions that fit each character's established demeanor.
    if name in ('fiona','demetrius'):
        p.r((26,41,50,44),a['skin']);p.r((36,43,43,43),'#8b696b')
    if name in ('henry','martha','donovan','shopkeeper'):
        for x in [24,50]:p.r((x,39,x+3,40),'#c3a18d')
    if name=='damian':
        p.r((24,29,34,30),'#3f383c');p.r((44,27,52,28),'#3f383c');p.r((50,39,52,41),'#b4887a')
    if name=='emile':
        p.r((36,43,43,47),'#643f39');p.r((38,44,41,47),'#ffefce')

def backhair(p,a,name):
    if name=='becky':
        for side in (0,1):
            x=11 if side==0 else 58
            p.e((x-7,27,x+11,58),O);p.e((x-5,29,x+8,55),'#46323e')
            p.e((x-6,48,x+8,69),O);p.e((x-4,48,x+6,65),'#5e3f47')
    elif name=='sylvia':
        p.p([(16,24),(21,16),(51,17),(62,31),(66,75),(57,96),(51,80),(48,41),(23,46),(17,86),(8,83)],O)
        p.p([(18,24),(23,17),(48,20),(60,34),(60,78),(56,86),(50,72),(47,41),(24,47),(18,80),(12,76)],'#ae5738')
        for x in (12,18,55,60):p.l([(x,42),(x-2,62),(x+2,74)],'#d87747',2)
    elif name=='melinda':
        p.e((10,20,27,82),O);p.e((49,18,67,83),O)
        p.e((13,22,26,78),'#42343b');p.e((51,21,63,79),'#42343b')
    elif name=='fiona':
        p.e((12,18,62,69),O);p.e((14,20,59,65),'#bfbaca')
    elif name=='martha':
        p.e((53,23,73,43),O);p.e((55,24,70,41),'#b1adb2')
    elif name=='camilla':
        p.e((50,18,73,45),O);p.e((53,20,70,43),'#d9b36c');p.p([(56,36),(71,40),(68,63),(58,62)],'#d7b578')
    elif name=='shopkeeper':
        p.p([(13,24),(20,16),(55,16),(66,24),(62,85),(53,85),(48,38),(24,38),(21,84),(13,82)],O)
        p.p([(15,26),(23,19),(52,19),(63,27),(59,83),(56,82),(50,38),(22,40),(19,79),(16,79)],'#e2e0d4')
    elif name=='yuri':
        p.p([(15,18),(23,9),(48,9),(62,18),(63,59),(52,61),(49,31),(24,31),(19,59),(13,57)],O)
        p.p([(18,18),(25,12),(48,12),(59,20),(58,50),(53,55),(49,29),(23,30),(20,51),(17,49)],'#2b3039')
    else:b.backhair(p,a)

def hairstyles(p,a,name):
    if name in ('becky','damian','emile','ewen','henry','franky','yuri','sylvia','fiona','melinda','demetrius','camilla'):
        b.hairstyle(p,a)
    elif name=='martha':
        p.p([(13,25),(17,14),(28,9),(49,10),(62,21),(60,38),(51,29),(45,19),(31,24),(21,37)],O)
        p.p([(16,25),(20,16),(29,12),(48,13),(58,20),(57,33),(49,26),(43,18),(32,22),(22,32)],'#b4b2ba')
        p.l([(20,22),(35,16),(54,19)],'#e3dfdc',3)
        p.p([(16,35),(21,27),(25,33),(22,52),(15,48)],'#b2b1b9')
    elif name=='donovan':
        # Character's iconic wide forehead, stiff dark hair, squared-off temple locks.
        p.p([(11,30),(12,13),(21,11),(21,5),(32,9),(39,5),(47,10),(56,7),(65,18),(63,39),(55,33),(50,21),(28,19),(19,33)],O)
        p.p([(14,28),(15,15),(25,13),(24,9),(33,12),(39,9),(48,13),(56,11),(62,20),(60,32),(55,29),(49,18),(28,17),(20,29)],'#34343b')
        for x in (19,25,43,54):p.r((x,12,x+4,15),'#626068')
    elif name=='shopkeeper':
        # Character-defining tan bucket hat and heavy brim, not silver hair / beard.
        p.p([(16,15),(21,5),(57,5),(62,16),(65,28),(57,35),(21,35),(12,29)],O)
        p.p([(19,15),(23,8),(54,8),(60,17),(61,27),(55,31),(21,31),(15,27)],'#beae85')
        p.p([(15,26),(62,27),(66,34),(50,38),(24,38),(10,33)],O)
        p.p([(16,28),(62,29),(62,33),(51,35),(24,35),(14,32)],'#9f946f')
        p.l([(27,13),(47,12)],'#dfd2a7',2)

def custom_outfit(p,name,a):
    sk=a['skin'];
    if name in ('becky','damian','emile','ewen','demetrius'):
        edenschool(p,name=='becky',sk);return
    if name=='sylvia':
        adult_tunic(p,'#22242e','#4a3c49',sk,skirt=True)
        # her dramatic white cravat and bow, dark fitted dress, netted stockings
        p.p([(28,57),(38,65),(48,56),(45,74),(37,72),(30,73)],'#ede2dc')
        p.p([(28,61),(37,69),(48,61),(42,83),(37,73),(32,82)],'#27202c')
        for y in range(94,101,3):
            for x in [27,45]:p.r((x,y,x+3,y+1),'#8c7879')
        return
    if name=='fiona':
        adult_tunic(p,'#243a56','#526481',sk,coat=True)
        p.p([(23,58),(53,58),(58,94),(18,94)],O)
        p.p([(26,59),(50,59),(54,91),(22,91)],'#2a3c5e')
        p.p([(30,60),(39,73),(49,60)],'#5c5f6e')
        for x,y in [(30,73),(44,73),(30,82),(44,82)]:p.r((x,y,x+2,y+2),'#e7be77')
        p.p([(21,65),(17,77),(20,88),(25,89)],'#2e4162')
        return
    if name=='martha':
        adult_tunic(p,'#292f3b','#565c68',sk)
        p.p([(28,59),(39,72),(48,59),(44,80),(34,80)],'#fbf0e8')
        p.p([(29,63),(38,79),(48,63),(43,82),(34,83)],'#f5e5d8')
        for x,y in [(30,64),(34,70),(39,74),(44,70),(47,64)]:p.r((x,y,x+2,y+2),'#b7a18a')
        p.e((36,63,43,71),'#cbb179');p.r((38,66,40,68),'#f9e8af')
        return
    if name=='melinda':
        adult_tunic(p,'#2b3654','#465b74',sk,skirt=True)
        # recognizable white blouse tucked into a full navy skirt
        p.p([(25,58),(52,58),(52,73),(23,73)],'#f8f1e9')
        p.p([(24,74),(53,74),(58,96),(18,96)],O)
        p.p([(26,75),(50,75),(54,93),(23,93)],'#2e384f')
        p.p([(26,60),(19,72),(22,83),(26,82),(31,64)],'#f5eadc')
        p.p([(50,60),(56,72),(55,83),(51,83),(45,64)],'#f5eadc')
        p.r((18,81,24,86),sk);p.r((52,81,58,86),sk)
        p.p([(33,59),(38,66),(43,60)],'#eee5df')
        return
    if name=='donovan':
        adult_tunic(p,'#af9a7e','#cbb394',sk,coat=True)
        p.p([(24,59),(53,59),(57,92),(20,92)],'#b4a081')
        p.p([(26,60),(51,60),(54,88),(23,88)],'#bca88a')
        p.p([(32,62),(43,62),(45,78),(31,78)],'#dfd9c9')
        p.p([(37,62),(40,62),(42,78),(39,79),(36,78)],'#423a45')
        for y in (70,78,86):
            for x in (31,46):p.e((x,y,x+2,y+2),'#57433c')
        return
    if name=='shopkeeper':
        adult_tunic(p,'#ddd7c5','#f4ead5',sk)
        # natural beige gardener top, deep brown braces and pendant
        p.p([(27,60),(50,60),(51,82),(24,82)],'#efebd9')
        p.p([(28,59),(20,65),(18,81),(23,85),(31,65)],'#eae4d3')
        p.p([(49,59),(56,66),(59,81),(54,84),(47,63)],'#ebe5d6')
        p.r((29,62,33,88),'#655c51');p.r((46,62,50,88),'#655c51')
        p.l([(36,63),(39,75),(43,64)],'#ae7858',2);p.e((35,76,43,86),'#c8a362')
        return
    if name=='camilla':
        adult_tunic(p,'#c78986','#e8b2a4',sk,skirt=True)
        p.p([(25,59),(53,60),(56,80),(21,80)],'#c78080')
        p.p([(28,61),(38,66),(48,61)],'#ffddba')
        p.p([(23,80),(54,80),(56,93),(20,93)],'#563d50')
        p.r((25,79,53,82),'#a86d7c');return
    if name=='henry':
        adult_tunic(p,'#3d3f4a','#707076',sk,coat=True)
        for y in range(86,105,5):
            for x in (27,31,46,49):p.r((x,y,x+1,y+3),'#9d9a93')
        p.l([(62,67),(65,67),(65,106)],'#816c51',3);p.e((62,104,67,108),'#bca77b')
        return
    if name=='franky':
        adult_tunic(p,'#f8e8d6','#f3debc',sk)
        p.r((28,60,32,82),'#806b58');p.r((45,60,49,82),'#806b58')
        p.p([(37,59),(40,59),(42,78),(39,82),(36,76)],'#bc6e3e')
        p.r((28,78,51,81),'#5f4852')
        return
    if name=='yuri':
        adult_tunic(p,'#304a46','#657b67',sk)
        p.p([(28,60),(37,69),(46,60)],'#d4cdb6')
        p.p([(36,68),(39,68),(41,79),(38,81),(35,79)],'#9e3c45')
        p.e((46,64,53,71),'#c6a26a')
        return

def iconic_details(p,name,a):
    sk=a['skin']
    if name=='becky':
        # White frilled ponytail scrunchies and gold hairclip on the bangs.
        for x in (11,64):
            for dx,dy in [(-5,0),(0,-4),(5,0),(0,4)]:p.e((x+dx-3,27+dy-3,x+dx+4,27+dy+4),WHITE)
            p.e((x-5,22,x+6,32),'#b68e83')
        p.r((24,20,30,23),'#e7c36e');p.r((26,18,28,25),'#dfaf58')
        p.r((28,37,32,39),'#e39f9b');p.r((46,36,51,38),'#e39f9b')
    if name=='damian':
        p.l([(52,35),(54,37),(52,40)],'#96796f',1)
        p.r((29,31,34,32),'#463843');p.r((44,30,49,31),'#463843')
    if name=='emile':
        p.r((36,45,42,48),'#fff4d7')
        p.r((38,46,40,49),'#ad8570')
    if name=='ewen':
        # prominent blond parted fringe, not the same bowl silhouette as Emile
        p.p([(14,18),(30,6),(43,12),(53,6),(60,14),(54,27),(41,22),(27,29)],O)
        p.p([(17,18),(30,10),(42,15),(53,10),(56,16),(50,24),(41,20),(27,26)],'#c7ae77')
        p.l([(31,12),(37,15),(49,12)],'#edcf92',3)
    if name=='henry':
        # striking white whiskers / beard and cane
        p.p([(30,44),(38,43),(41,44),(48,43),(43,48),(39,46),(33,49)],'#e5e2da')
        p.p([(37,47),(42,47),(43,55),(38,61),(35,55)],'#dfddd4')
        p.r((27,35,32,36),'#625f66');p.r((45,34,50,35),'#625f66')
    if name=='franky':
        for x in (23,44):
            p.r((x,28,x+12,39),O);p.r((x+2,30,x+10,37),'#d0e7da')
            p.r((x+3,31,x+6,34),'#504a4f')
        p.r((34,32,44,34),O)
        p.p([(34,47),(38,45),(42,47),(43,51),(34,51)],'#795447')
    if name=='sylvia':
        p.r((24,33,33,37),'#b5afa8');p.r((45,33,54,37),'#b5afa8');p.r((32,34,46,35),'#c0bab3')
        p.r((25,34,33,35),'#524353');p.r((45,34,53,35),'#524353')
        p.l([(13,49),(12,72),(18,91)],'#d86d50',2)
    if name=='fiona':
        p.p([(13,20),(25,12),(58,11),(52,30),(42,50),(19,49)],'#d9d8df')
        p.p([(19,20),(39,15),(52,15),(43,32),(30,37)],'#f1ecf0')
        # front swept fringe hides right-side eye in front view
        p.p([(42,15),(56,19),(51,43),(45,43),(37,29)],'#ddd8e0')
        p.r((24,35,32,37),'#55516b')
    if name=='martha':
        p.l([(22,45),(24,49)],'#8b7f7e',1);p.l([(52,45),(50,50)],'#8b7f7e',1)
        p.e((34,59,45,68),'#d3bb7b');p.r((38,61,41,65),'#fff2bf')
    if name=='melinda':
        for x in range(31,48,4):p.e((x,54,x+3,57),'#efe2ce')
        p.e((20,41,23,45),'#d5c290')
    if name=='donovan':
        p.l([(22,26),(26,32),(23,40)],'#956d6b',2)
        p.l([(55,26),(51,33),(54,40)],'#956d6b',2)
        p.r((25,34,33,35),'#665553');p.r((44,34,52,35),'#665553')
    if name=='demetrius':
        p.r((27,31,35,32),'#363c46');p.r((45,31,52,32),'#363c46')
        p.r((37,44,42,44),'#9c7674')
    if name=='camilla':
        p.e((19,39,25,47),'#f3c468');p.e((53,39,59,47),'#f3c468')
        p.r((50,20,55,24),'#edcf91')
    if name=='shopkeeper':
        p.r((21,28,54,34),'#9f9171')
        # squinted eyes / graying forehead; the actual design does NOT have a full beard
        p.r((26,33,33,36),'#514a46');p.r((44,33,51,36),'#514a46')
        p.r((31,39,49,44),'#8c8980')
        p.r((37,43,43,44),'#59544b')

# Write only the 15 named supporting cast; preserve all principal original art.
cast=('becky','damian','emile','ewen','henry','franky','yuri','sylvia','fiona','martha','melinda','donovan','demetrius','camilla','shopkeeper')
for name in cast:
    a=dict(b.profiles[name]);
    if name=='shopkeeper':a['skin']='#a29f97'
    p=P();backhair(p,a,name)
    custom_outfit(p,name,a)
    detail_face(p,a,name)
    hairstyles(p,a,name)
    iconic_details(p,name,a)
    p.show(name)
b.draw_chimera()
print(f'Wrote {len(cast)} bespoke supporting figures + Mr Chimera; 4 principal sprites and explorer retained.')
