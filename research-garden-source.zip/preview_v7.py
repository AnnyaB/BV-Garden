from playwright.sync_api import sync_playwright
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
s=Path('/mnt/data/The_Latent_Atlas_Research_Garden_Playable.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1536,'height':960},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(s,wait_until='load');page.wait_for_timeout(400)
 page.evaluate('openChapter(0)');page.evaluate('beginQuest("stage",0)')
 page.evaluate('document.getElementById("journal-content").scrollTop=document.getElementById("journal-content").scrollHeight')
 page.evaluate('document.getElementById("explore").scrollIntoView()');page.wait_for_timeout(350)
 page.screenshot(path='/mnt/data/Research_Garden_Actual_Challenge_UI.png')
 page.evaluate('quest.passed.fill(true);quest.stars.fill(true);quest.imperial=true;quest.active=null;repairProgress();imgs.explorer.src=asset("explorer_scholar");progress();ribbon();openChapter(20)')
 page.evaluate('document.getElementById("explore").scrollIntoView()');page.wait_for_timeout(450)
 page.screenshot(path='/mnt/data/Research_Garden_Imperial_Scholar_Actual_UI.png')
 print('errors',errors)
 b.close()
