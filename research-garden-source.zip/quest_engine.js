/* RESEARCH GARDEN QUEST ENGINE · 20 chapters, nonrepeating conceptual question IDs, real scoring. */
'use strict';
const QUEST_STORAGE='latent-atlas-research-quest-v1';
const initQuest=()=>({passed:Array(20).fill(false),stars:Array(20).fill(false),bolts:0,used:{},active:null,last:null,imperial:false,examPass:false,epoch:0});
let quest=initQuest();
try{const old=JSON.parse(localStorage.getItem(QUEST_STORAGE)||'null');if(old&&Array.isArray(old.passed)&&old.passed.length===20&&Array.isArray(old.stars)&&old.stars.length===20){
 quest={...initQuest(),...old};quest.passed=old.passed.map(Boolean);quest.stars=old.stars.map(Boolean);quest.bolts=Math.max(0,Math.min(10,Number(old.bolts)||0));
}}catch(_){/* storage unavailable => session-only state */}
function storeQuest(){try{localStorage.setItem(QUEST_STORAGE,JSON.stringify(quest));}catch(_){}}
function canEnterZone(x,y){return !chapters.some((ch,i)=>i>state.current&&Math.hypot(x-ch.place[0],y-ch.place[1])<3.5);}
function move(dx,dy){if(state.travel)state.travel=null;const nx=Math.max(0,Math.min(NX-1,state.player.x+dx)),ny=Math.max(0,Math.min(NY-1,state.player.y+dy));if(!canEnterZone(nx,ny)){showRewardToast('tonitrus','Concept gate locked · resolve the four obstacles');return;}state.player.x=nx;state.player.y=ny;}
function repairProgress(){state.completed.clear();for(let i=0;i<20;i++){if(!quest.passed[i])break;state.completed.add(i);}state.current=state.completed.size;state.correctAnswered=false;}
repairProgress();
let quizSelected=Array.isArray(quest.active?.selected)?quest.active.selected.slice():[];
const qEsc=t=>String(t).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const asset=id=>typeof INLINE_SPRITES!=='undefined'?INLINE_SPRITES[id]:`assets/${id}.png`;
const iconStar=()=>`<img class="reward-img" src="${asset('stella')}" alt="Stella Star">`;
const iconBolt=()=>`<img class="reward-img" src="${asset('tonitrus')}" alt="Tonitrus Bolt">`;
function shuffleQuest(values){const x=values.slice();for(let i=x.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[x[i],x[j]]=[x[j],x[i]];}return x;}
const questionsFor=(kind,level,d)=>kind==='exam'?IMPERIAL_BANK[d]:CHALLENGE_BANK[level][d];
const questionId=(kind,level,d,i)=>`${kind}:${level}:${d}:${i}`;
function pickQuestQuestion(kind,level,d){const all=questionsFor(kind,level,d);const eligible=all.map((r,i)=>i).filter(i=>!quest.used[questionId(kind,level,d,i)]);
 if(!eligible.length)return null;const i=eligible[Math.floor(Math.random()*eligible.length)],source=all[i],options=shuffleQuest([...source.a.map(s=>({s,ok:true})),...source.b.map(s=>({s,ok:false}))]);
 const id=questionId(kind,level,d,i);quest.used[id]=true;
 return{id,level,d,index:i,options:options.map(o=>o.s),answer:options.flatMap((o,j)=>o.ok?[j]:[]),chosen:null,correct:null};
}
function hasQuestions(kind,level){const needs=kind==='exam'?{e:2,m:3,h:5}:{e:1,m:1,h:2};return Object.entries(needs).every(([d,n])=>questionsFor(kind,level,d).filter((q,i)=>!quest.used[questionId(kind,level,d,i)]).length>=n);}
function beginQuest(kind,level){if(quest.imperial)return;
 if(kind==='stage'&&level>state.current)return;
 if(kind==='stage'&&quest.stars[level])return;
 if(kind==='exam'&&!(state.current===20&&quest.stars.every(Boolean)))return;
 if(quest.active){if(quest.active.kind===kind&&quest.active.level===level){openChapter(kind==='exam'?20:level);return;}
   quest.last={kind,level,blocked:true,msg:`Finish your current ${quest.active.kind==='exam'?'Imperial exam':`chapter ${quest.active.level+1}`} trial before starting another.`};openChapter(kind==='exam'?20:level);return;}
 if(!hasQuestions(kind,level)){quest.last={kind,level,exhausted:true,msg:'This chapter has no unused questions left in the offline bank. Repeating a previously seen question would violate the no-repeat rule.'};storeQuest();openChapter(kind==='exam'?20:level);return;}
 const tiers=kind==='exam'?['e','e','m','m','m','h','h','h','h','h']:['e','m','h','h'];
 quest.last=null;quest.active={kind,level,items:tiers.map(d=>pickQuestQuestion(kind,level,d)),position:0,results:[],selected:[],created:Date.now()};quizSelected=[];storeQuest();openChapter(kind==='exam'?20:level);
}
function selectQuizOption(j){const a=quest.active;if(!a)return;const q=a.items[a.position];if(!q||q.correct!==null)return;
 const multiple=(a.kind==='exam'||a.level>=5);
 quizSelected=multiple?(quizSelected.includes(j)?quizSelected.filter(x=>x!==j):[...quizSelected,j]):[j];
 a.selected=quizSelected.slice();storeQuest();updateQuizArea();
}
function submitQuizAnswer(){const a=quest.active;if(!a)return;const q=a.items[a.position];if(!q||q.correct!==null||!quizSelected.length)return;
 const selected=quizSelected.slice().sort((x,y)=>x-y),expected=q.answer.slice().sort((x,y)=>x-y);
 q.correct=JSON.stringify(selected)===JSON.stringify(expected);q.chosen=selected;
 a.results.push({d:q.d,ok:q.correct,id:q.id});a.position++;quizSelected=[];a.selected=[];
 if(!q.correct){quest.bolts++;showRewardToast('tonitrus','Tonitrus obstacle encountered · +1 Bolt');if(quest.bolts>10){restartForBolts();return;}}
 if(a.position>=a.items.length)resolveAttempt();
 storeQuest();progress();if(a&&a.kind==='stage')openChapter(a.level);else openChapter(20);
}
function restartForBolts(){const history=quest.used,epoch=(quest.epoch||0)+1;quest=initQuest();quest.used=history;quest.epoch=epoch;repairProgress();quest.last={kind:'stage',level:0,reset:true,msg:'Eleventh Tonitrus Bolt! Back to chapter 01. Previously used questions remain retired.'};state.player={x:chapters[0].place[0]+.5,y:chapters[0].place[1]+.8};state.travel=null;storeQuest();progress();ribbon();openChapter(0);}
function resolveAttempt(){const a=quest.active,hard=a.results.filter(r=>r.d==='h'&&r.ok).length,correct=a.results.filter(r=>r.ok).length;
 if(a.kind==='stage'){
   const earned=correct>=3,passed=earned||(hard===2);
   if(passed){quest.passed[a.level]=true;if(earned){quest.stars[a.level]=true;showRewardToast('stella','Stella Star earned!');}else showRewardToast('stella','Golden path unlocked · no Stella yet');repairProgress();}
   quest.last={kind:'stage',level:a.level,passed,earned,correct,hard,msg:earned?'Stella earned! At least three correct.':passed?'Both hard challenges passed — next chapter unlocked, but no Stella. Replay with fresh questions to earn it.':'The gate remains closed. Review the lesson and retry with unused questions.'};
 }else{
   const passed=correct>=9&&hard>=4;quest.imperial=passed;quest.examPass=passed;
   quest.last={kind:'exam',level:20,passed,correct,hard,msg:passed?'Imperial Scholar! The academy cape is unlocked. This is an in-game honor, not a scientific credential.':'Exam not passed. You need at least 9/10, including 4/5 hard questions. A new attempt requires unused questions.'};
   if(passed){imgs.explorer.src=asset('explorer_scholar');showRewardToast('stella','Imperial Scholar · Academy cape unlocked!');}
 }
 quest.last.breakdown=a.items.map(item=>{const reference=questionsFor(a.kind,a.level,item.d)[item.index];return {tier:item.d,ok:item.correct,prompt:reference.t,expected:item.answer.map(j=>item.options[j]),why:reference.why};});
 quest.active=null;storeQuest();ribbon();
}
if(quest.imperial){imgs.explorer.src=asset('explorer_scholar');}
function updateQuizArea(){const region=document.getElementById('quest-quiz');if(region)region.innerHTML=quizAreaContent();}
function quizAreaContent(){const a=quest.active;if(!a)return '';
 const q=a.items[a.position];if(!q)return '';
 const multiple=a.kind==='exam'||a.level>=5;
 const tier={e:'EASY · fundamentals',m:'MEDIUM · reasoning',h:'HARD · research-grade'}[q.d];
 const correctSoFar=a.results.filter(x=>x.ok).length;
 const which=a.kind==='exam'?`IMPERIAL EXAM · QUESTION ${a.position+1}/10`:`CHAPTER ${String(a.level+1).padStart(2,'0')} · OBSTACLE ${a.position+1}/4`;
 return `<div class="quest-question"><div class="quest-topline"><span>${which}</span><strong>${tier}</strong></div><div class="quest-dots">${a.items.map((z,i)=>`<span class="${i<a.position?(z.correct?'right':'wrong'):i===a.position?'here':''}"></span>`).join('')}</div><p class="quest-prompt">${qEsc(questionsFor(a.kind,a.level,q.d)[q.index].t)}</p><div class="quest-option-list">${q.options.map((op,j)=>`<button type="button" data-quest-choice="${j}" class="quest-choice ${quizSelected.includes(j)?'picked':''}" aria-pressed="${quizSelected.includes(j)}"><span class="choice-box">${multiple?'▢':'◯'}</span>${qEsc(op)}</button>`).join('')}</div><p class="quest-hint">${multiple?'MULTI-SELECT · choose every valid statement':'SINGLE CHOICE · choose one defensible answer'} · No second guesses after submitting.</p><button type="button" class="action-button quest-submit" data-quest-submit ${quizSelected.length?'':'disabled'}>Lock answer · face the Tonitrus obstacle →</button><div class="quest-score">Correct so far: <strong>${correctSoFar}/${a.position}</strong> · ${iconBolt()} ${quest.bolts}/10 bolts</div></div>`;
}
function showRewardToast(kind,message){const box=document.getElementById('gameToast');if(!box)return;box.innerHTML=`<img class="reward-img" src="${asset(kind)}" alt=""><strong>${qEsc(message)}</strong>`;box.classList.remove('hidden');clearTimeout(showRewardToast._timer);showRewardToast._timer=setTimeout(()=>box.classList.add('hidden'),2500);}
function reviewAfterRound(last){if(!Array.isArray(last.breakdown))return '';return `<details class="quest-debrief"><summary>Study the completed challenge · explanations after all submissions</summary>${last.breakdown.map((z,i)=>`<div class="quest-debrief-item"><strong>${i+1}. ${z.ok?'✓ CORRECT':'✕ INCORRECT'} · ${z.tier.toUpperCase()}</strong><p>${qEsc(z.prompt)}</p><p><b>Defensible selection:</b> ${z.expected.map(qEsc).join(' + ')}</p><p>${qEsc(z.why)}</p></div>`).join('')}</details>`;}
function challengeWidget(level){const active=quest.active,own=quest.stars[level],passed=quest.passed[level],last=quest.last&&quest.last.kind==='stage'&&quest.last.level===level?quest.last:null;
 let html=`<div class="challenge-stage"><h5>05 · THE TONITRUS OBSTACLE COURSE</h5><p>Four conceptual challenges: <strong>1 easy + 1 medium + 2 hard</strong>. A Stella needs ≥3 correct; both hard correct can unlock the next chapter without a Stella. Wrong answers add Tonitrus Bolts, and the 11th Bolt restarts at level 01.</p><div class="chapter-award-line">${own?iconStar():iconBolt()} <strong>${own?'Stella collected':passed?'Unlocked without Stella':'Chapter gate awaiting challenge'}</strong></div>`;
 if(active&&active.kind==='stage'&&active.level===level)html+=`<div id="quest-quiz">${quizAreaContent()}</div>`;
 else if(active)html+=`<p class="quest-notice">An unfinished challenge is active in chapter ${active.level+1}. Complete it before starting another.</p><button class="action-button" data-quest-return>Return to the active challenge →</button>`;
 else if(own)html+=`<div class="quest-notice success">${iconStar()} This chapter's Stella has been collected. Scientific reading and workshops remain available.</div>`;
 else {if(last)html+=`<div class="quest-notice ${last.passed?'success':''}"><strong>${last.correct!==undefined?`${last.correct}/4 correct · ${last.hard}/2 hard · `:''}${last.passed?'GATE OPEN':'GATE CLOSED'}</strong><p>${qEsc(last.msg)}</p></div>${reviewAfterRound(last)}`;
  if(!last?.exhausted)html+=`<button class="action-button" data-quest-start="stage:${level}">${passed?'Retry for your missing Stella':'Face four randomized conceptual obstacles'} →</button>`;
 }
 if(passed&&level+1<20)html+=`<button class="action-button next-quest" data-quest-next="${level}">Follow the golden path to ${qEsc(chapters[level+1].short)} →</button>`;
 html+='</div>';return html;
}
const DEEP_LESSONS=[
['Trace the field historically: symbolic search is good at explicit discrete rules, statistical learning estimates patterns from data, neural representation learning learns features, and embodied models must predict intervention effects. None by itself is a complete definition of intelligence.','Thought experiment: a chess expert and a kitchen robot both plan, but differ in observation, motor constraints, uncertainty and recovery.','False claim to reject: success on one leaderboard means unrestricted cross-domain competence.'],
['Separate observations, latent assumptions, labels and decisions. Boolean logic encodes what follows from propositions; noisy sensors make the truth of propositions uncertain. Provenance, units and temporal ordering determine whether data can justify a claim.','If a robot sees no obstacle because its camera is blocked, “unknown” must not silently become “false.”','False claim to reject: a high confidence number substitutes for independently measured ground truth.'],
['Reliable scientific code specifies inputs, outputs, invariants and failure behavior. BFS and Dijkstra are not interchangeable under arbitrary edge costs; seeds do not replace environment pinning and deterministic controls.','Debug a planner that uses a stack rather than a queue, then test paths with cycles and non-unit costs.','False claim to reject: one passing run rules out hidden bugs and implementation confounding.'],
['Vectors describe features; linear maps can collapse information; derivatives describe local sensitivity. Probability distinguishes prior, likelihood, posterior and base rates, while correlation alone cannot identify a causal intervention.','If two physical scenes look identical but have different hidden friction, a one-frame observation may not identify their future transitions.','False claim to reject: a low-dimensional latent is automatically sufficient for control.'],
['An optimizer follows a stated objective, not an unstated intent. Training loss, validation loss and real-world task utility can diverge; large step sizes can destabilize learning while excessive tuning can overfit validation protocols.','A pixel-loss predictor that ignores rare collisions can have excellent mean metrics yet choose hazardous plans.','False claim to reject: lower objective value proves the intended physical behavior.'],
['Define population, target distribution and support before claiming generalization. Stratify by important failure mechanisms; report calibration, rare-event accuracy, across-seed variance and distribution-shift tests.','A hospital image model may exploit acquisition-site artifacts rather than tumour biology.','False claim to reject: high average in-distribution accuracy demonstrates robustness to unknown shifts.'],
['Backpropagation computes gradients through an architecture; architecture itself provides inductive biases. CNN locality, attention and recurrent memory can help, but causal dynamics and action-conditioned state need separate evidence.','A visually accurate grasp predictor can still fail when contact forces or motor delays change.','False claim to reject: a transformer with enough parameters necessarily understands physical interventions.'],
['Self-supervision manufactures learning targets from the input stream. View creation, masking, target branches, negative sampling and stop-gradient are design decisions, each capable of encouraging or suppressing important information.','A crop that removes the gripper can improve object identity invariance while making downstream manipulation worse.','False claim to reject: any pretrained embedding is automatically useful for control.'],
['A latent representation is useful when it preserves variables necessary for the intended computation. For planning, task sufficiency depends on actions and transitions, not merely reconstruction or semantic clusters.','Identical-looking objects with different friction require belief maintenance or intervention to choose a reliable push.','False claim to reject: a linear probe failing to decode a variable proves that variable is absent.'],
['Energy models rank configurations through a learned scalar; they need not output normalized probabilities. Energy minimization can find local minima, reward shortcuts or impossible but low-energy states.','Compare energies assigned to feasible and colliding grasp trajectories under unseen object configurations.','False claim to reject: low learned energy mathematically certifies physical safety.'],
['Joint-embedding prediction fits target feature structure rather than necessarily reconstructing pixels. Choices about target network, masking and temporal conditioning determine which information becomes predictable and which is discarded.','A JEPA-style video predictor can model appearance while failing when the robot introduces an unseen action.','False claim to reject: low latent error proves action-conditioned physical correctness.'],
['Dynamics models estimate transitions conditioned on state and action; a belief state represents uncertainty under partial observation. A useful model needs supported actions, reasonable long rollouts and awareness of observation delays.','The same image position with different velocities can lead to different next frames under identical motor input.','False claim to reject: excellent one-step held-out RMSE guarantees good closed-loop performance.'],
['World models support imagined candidate futures and model-based policies, but an optimizer can amplify their errors. Test with held-out actions, longer horizons, unknown physics and closed-loop task metrics.','A planner discovers an implausible high-reward path because its learned model predicts collision-free motion through a wall.','False claim to reject: realistic frames certify an adequate world model.'],
['MPC repeatedly solves a bounded planning problem and executes a small portion, updating the plan with feedback. Horizon, latency, model bias, constraints and terminal costs affect outcomes.','A longer MPC horizon can make real performance worse if uncertain model rollouts dominate the chosen action.','False claim to reject: replanning makes an incorrect physical model harmless.'],
['MCTS searches candidate action trees; diffusion planners iteratively refine candidate trajectories. MCTD is a particular tree-diffusion approach, not an abbreviation for ordinary Monte Carlo search.','A deeper tree with a biased learned evaluator can be confidently wrong and consume far more inference compute.','False claim to reject: more search automatically guarantees safer or globally optimal action.'],
['Object-centric and factorized models represent structured entities and their relations. Contact graphs, temporal identity and skill preconditions matter; unseen combinations can invalidate simplistic independence assumptions.','Two individually learned grasp and rotate skills may fail in composition when the grasp state violates the rotation preconditions.','False claim to reject: adding object slots guarantees systematic compositional generalization.'],
['Embodied learning couples observation, proprioception, actuation, physics, latency and contact. Sim-to-real requires explicit validation of both visual and dynamic shift, not just photorealistic simulation.','An identical-looking cup with new mass distribution can slip despite a grasp that worked in the training simulator.','False claim to reject: a good image encoder removes the need for contact modeling.'],
['Distinguish epistemic uncertainty from irreducible outcome randomness, and distinguish both from a calibrated hazard bound. Safety contracts are conditional on assumptions; a learned shield may fail off support.','An abstaining controller might have low risk when acting but poor task coverage; report both.','False claim to reject: zero failures in a small test set proves zero risk.'],
['Active physical reasoning links evidence gaps to targeted interventions. A useful self-repairing model must distinguish uncertainty detection, diagnosis, safe experiment choice, updating, retention and recovery.','A robot tests whether an object is heavy using a small, bounded probe rather than repeatedly applying force based on a mistaken estimate.','False claim to reject: an extra adaptation module constitutes scientific invention without controlled ablation.'],
['Open-ended intelligence is a research frontier, not an established engineering achievement. Experiments must disentangle task-generator artifacts, forgetting, resource cost, self-evaluation bias, safety and independent novel-task transfer.','An autonomous agent may appear to improve indefinitely on its own generated tasks while overfitting the generator or misleading its evaluator.','False claim to reject: clearing a game or a benchmark proves AGI, ASI or recursive self-improvement.']
];
function deepHTML(i){const d=DEEP_LESSONS[i];return `<div class="deep-primer"><h5>Concept mechanics · why it matters</h5><p>${qEsc(d[0])}</p><h5>Concrete reasoning case</h5><p>${qEsc(d[1])}</p><h5>Common misconception to defeat</h5><p>${qEsc(d[2])}</p></div>`;}
function article(ch){const i=ch.index,passed=quest.passed[i];return `<article class="chapter-article"><div class="chapter-tag">CHAPTER ${String(i+1).padStart(2,'0')} / 20 · ${qEsc(ch.tag)}</div><div class="guide-header"><img src="${asset(ch.id)}" alt="Pixel art research companion for ${qEsc(ch.short)}"><div><h4>${qEsc(ch.title)}</h4><p>${qEsc(ch.short)}</p></div></div><p class="lede">${qEsc(ch.tag)}</p><h5>01 · First principles</h5><p>${qEsc(ch.known)}</p><div class="math-line">${qEsc(ch.math)}</div>${deepHTML(i)}<h5>02 · Practice and reproducibility</h5><p>${qEsc(ch.experiment)}</p>${window.microLabHTML?microLabHTML(ch):''}${ch.role==='dynamics'?toyHTML():''}${ch.role==='energy'?energyHTML():''}<div class="frontier"><h5>03 · Open research limitation</h5><p>${qEsc(ch.frontier)}</p></div><a href="${qEsc(ch.source)}" class="paper-link" target="_blank" rel="noopener noreferrer">↗ VERIFIED READING<br><span style="font-weight:500">${qEsc(ch.paper)}</span></a>${challengeWidget(i)}${passed?`<p class="chapter-finished">✓ Chapter gate passed. ${quest.stars[i]?'Stella collected.':'A Stella can still be earned using unused questions.'}</p>`:''}</article>`;}
function progress(){const count=state.completed.size,num=quest.stars.filter(Boolean).length;
 document.getElementById('progress-numeric').innerHTML=`${String(count).padStart(2,'0')} <small>/ ${chapters.length}</small>`;
 document.getElementById('progress-fill').style.width=`${count/20*100}%`;
 const reward=document.getElementById('rewardStrip');if(reward)reward.innerHTML=`<span>${iconStar()} <strong>${num}/20</strong> Stella Stars</span><span>${iconBolt()} <strong>${quest.bolts}/10</strong> Tonitrus Bolts</span>${quest.imperial?'<b class="imperial-mini">IMPERIAL SCHOLAR</b>':''}`;
}
function ribbon(){const root=document.getElementById('chapter-ribbon');root.innerHTML=chapters.map((ch,i)=>`<button type="button" role="listitem" class="chapter-button ${quest.passed[i]?'done':''} ${state.current===i?'active':''} ${i>state.current?'locked':''}" data-chapter="${i}" aria-label="Chapter ${i+1} ${qEsc(ch.short)}${i>state.current?' locked':''}"><span class="chapter-no">${String(i+1).padStart(2,'0')} / 20</span><span class="chapter-title">${qEsc(ch.short)}</span><span class="chapter-status">${i>state.current?`${iconBolt()} LOCKED`:quest.stars[i]?`${iconStar()} STELLA`:quest.passed[i]?'✓ cleared · Stella missing':'Face the challenge'}</span></button>`).join('');}
function lockedArticle(i){return `<article class="chapter-article"><div class="chapter-tag">${iconBolt()} RESEARCH OBSTACLE LOCKED</div><h4>${qEsc(chapters[i].short)}</h4><p>Complete every prior chapter’s four-question gate in sequence. Future chapters cannot be reached by skipping the golden thread.</p><p>Current gate: <strong>${state.current<20?`${state.current+1} · ${qEsc(chapters[state.current].short)}`:'all research chapters passed'}</strong>.</p><button class="action-button" data-goto-next>Return to the current gate →</button></article>`;}
function completeScreen(){const have=quest.stars.filter(Boolean).length;
 const last=quest.last?.kind==='exam'?quest.last:null;
 if(quest.imperial)return `<article class="chapter-article imperial-win"><div class="chapter-tag">20 STELLAS · IMPERIAL EXAM PASSED</div><img class="scholar-portrait" src="${asset('explorer_scholar')}" alt="Explorer wearing the black cape, dark-red lining and gold cord of an Imperial Scholar"><h4>Imperial Scholar</h4><p class="lede">A special in-game academic honor. Your explorer now wears a black cape with dark-red lining and gold fastening inspired by Eden Academy.</p><p>Real research credentials require independent evidence, publication and reproducibility. This game does not confer academic qualification.</p><button class="action-button" data-chapter="19">Review the theoretical frontier →</button></article>`;
 const need=quest.stars.map((s,i)=>!s?i:-1).filter(i=>i>=0);
 let html=`<article class="chapter-article"><div class="chapter-tag">THE IMPERIAL SCHOLAR QUALIFIER</div><h4>20 Stella Stars before the final exam</h4><p class="lede">${have}/20 Stella Stars earned. All 20 chapter gates may be passed without collecting every Stella; return to missing stages and earn their stars before entering the exam.</p><div class="scholar-gallery">${iconStar()} ${have}/20 Stellas · ${iconBolt()} ${quest.bolts}/10 Tonitrus</div>`;
 if(have<20){html+=`<div class="quest-notice"><strong>Imperial exam locked.</strong><p>Missing Stella stages: ${need.map(i=>String(i+1).padStart(2,'0')).join(', ')}. Every new attempt draws unused questions.</p></div><button class="action-button" data-chapter="${need[0]}">Return to missing Stella · level ${need[0]+1} →</button>`;}
 else if(quest.active?.kind==='exam'){html+=`<div id="quest-quiz">${quizAreaContent()}</div>`;}
 else{html+=`<p>Final exam: <strong>10 challenging questions</strong> — 2 easy, 3 medium, 5 advanced research questions. Scoring requires 9/10 correct and at least 4/5 hard questions.</p>`;
 if(last)html+=`<div class="quest-notice ${last.passed?'success':''}"><strong>${last.correct}/10 overall · ${last.hard}/5 hard</strong><p>${qEsc(last.msg)}</p></div>${reviewAfterRound(last)}`;
 if(!last?.exhausted)html+=`<button class="action-button" data-quest-start="exam:20">Begin the Imperial Scholar examination →</button>`;
 }
 return html+'</article>';
}
function openChapter(i){if(state.travel)return;
 if(i>=20){state.selection=20;document.getElementById('journal-content').innerHTML=completeScreen();document.getElementById('journal-content').scrollTop=0;return;}
 state.selection=i;state.correctAnswered=false;document.getElementById('journal-content').innerHTML=i>state.current?lockedArticle(i):article(chapters[i]);document.getElementById('journal-content').scrollTop=0;
 document.getElementById('map-location').textContent=(i>state.current?'Locked: ':'Exploring: ')+chapters[i].short;
 document.getElementById('worldTip').textContent=i>state.current?'Tonitrus gate ahead · complete earlier stages':'Research obstacles · earn Stella Stars';ribbon();progress();
}
function beginNext(i){if(i>=20||!quest.passed[i])return;
 if(i===19){openChapter(20);return;}
 const next=chapters[i+1];state.travel={start:performance.now(),from:{...state.player},to:{x:next.place[0]+.5,y:next.place[1]+.8}};
 document.getElementById('worldTip').textContent=`Following the golden path to ${next.short} →`;
}
// The original reset handler would silently erase progress without preserving used questions; replace it.
const resetControl=document.getElementById('reset-progress');const newReset=resetControl.cloneNode(true);resetControl.replaceWith(newReset);
newReset.textContent='restart adventure';newReset.addEventListener('click',()=>{
 if(!window.confirm('Restart your adventure from level 01? Previous questions stay retired and are NEVER reused.'))return;
 const history=quest.used,epoch=(quest.epoch||0)+1;quest=initQuest();quest.used=history;quest.epoch=epoch;repairProgress();storeQuest();state.travel=null;state.player={x:chapters[0].place[0]+.5,y:chapters[0].place[1]+.8};progress();ribbon();openChapter(0);
});
document.addEventListener('click',ev=>{
 const start=ev.target.closest('[data-quest-start]');if(start){const [kind,index]=start.dataset.questStart.split(':');beginQuest(kind,Number(index));return;}
 const choice=ev.target.closest('[data-quest-choice]');if(choice){selectQuizOption(Number(choice.dataset.questChoice));return;}
 if(ev.target.closest('[data-quest-submit]')){submitQuizAnswer();return;}
 const go=ev.target.closest('[data-quest-next]');if(go){beginNext(Number(go.dataset.questNext));return;}
 if(ev.target.closest('[data-quest-return]')){if(quest.active)openChapter(quest.active.kind==='exam'?20:quest.active.level);return;}
});
progress();ribbon();

