/* Accessibility and world exploration controls. No changes to scoring or chapter locks. */
'use strict';
(() => {
  const nav = document.getElementById('garden-tour');
  const openButton = document.getElementById('garden-index-toggle');
  const centerButton = document.getElementById('garden-center');
  const map = document.getElementById('world');
  const held = new Set();
  let last = 0;
  let drag = null;
  let skipClick = false;
  const important = ['INPUT', 'TEXTAREA', 'SELECT'];
  const isEditing = el => important.includes(el?.tagName) || !!el?.isContentEditable;
  const chapterLabel = i => `${String(i+1).padStart(2,'0')} · ${chapters[i].short}`;
  const arrow = {arrowup:[-1,0],w:[-1,0],arrowdown:[1,0],s:[1,0],arrowleft:[0,1],a:[0,1],arrowright:[0,-1],d:[0,-1]};
  const nearChapter = () => chapters.reduce((best,ch,i) => {
    const dist = Math.hypot(state.player.x - (ch.place[0]+.5),state.player.y-(ch.place[1]+.8));
    return dist < best.d ? {i,d:dist} : best;
  },{i:Math.min(19,state.current),d:Infinity});
  function visit(i) {
    if(!Number.isInteger(i)||i<0||i>=chapters.length)return;
    state.travel=null;state.player={x:chapters[i].place[0]+.5,y:chapters[i].place[1]+.8};
    state.explorePan={x:0,y:0}; held.clear();
    // Sightseeing is unrestricted; lessons still enforce the original progression.
    openChapter(i);
    nav.hidden=true;openButton.setAttribute('aria-expanded','false');
    map.focus({preventScroll:true});
  }
  function toggle(force){const on=typeof force==='boolean'?force:nav.hidden; nav.hidden=!on;openButton.setAttribute('aria-expanded',String(on));if(on)nav.querySelector('button')?.focus();else openButton.focus();}
  nav.innerHTML='<div class="garden-tour-head"><strong>Visit any station</strong><button type="button" id="garden-close" aria-label="Close research map">×</button></div><p>Walk freely between all 20 companions; locked lessons remain locked.</p><div class="garden-tour-grid">'+chapters.map((ch,i)=>`<button type="button" data-visit="${i}" aria-label="Visit station ${chapterLabel(i)}">${String(i+1).padStart(2,'0')} <span>${ch.short}</span></button>`).join('')+'</div>';
  nav.addEventListener('click',ev=>{const b=ev.target.closest('[data-visit]'); if(b){visit(Number(b.dataset.visit));return;}if(ev.target.closest('#garden-close'))toggle(false);});
  openButton.addEventListener('click',()=>toggle());
  centerButton.addEventListener('click',()=>{state.explorePan={x:0,y:0};map.focus({preventScroll:true});});
  // Override ONLY physical roaming restrictions; openChapter() still protects all lesson gates.
  canEnterZone=function(){return true;};
  move=function(dx,dy){state.travel=null;state.player.x=Math.max(0,Math.min(NX-1,state.player.x+dx));state.player.y=Math.max(0,Math.min(NY-1,state.player.y+dy));state.explorePan={x:0,y:0};};
  state.explorePan={x:0,y:0};
  function pan(dx,dy){state.explorePan.x=Math.max(-1800,Math.min(1800,state.explorePan.x+dx));state.explorePan.y=Math.max(-1100,Math.min(1100,state.explorePan.y+dy));}
  document.addEventListener('keydown',ev=>{
    if(isEditing(ev.target)||ev.ctrlKey||ev.metaKey||ev.altKey)return;
    const key=ev.key.toLowerCase();
    if(arrow[key]){
      if(ev.shiftKey){const [dx,dy]=arrow[key];pan(-dx*34-dy*30,-dx*18+dy*18);}
      else {held.add(key);if(!ev.repeat){const [dx,dy]=arrow[key];move(dx*.35,dy*.35);}}
      ev.preventDefault();ev.stopImmediatePropagation();return;
    }
    if(key==='m'){toggle();ev.preventDefault();return;}
    if(key==='f'){state.explorePan={x:0,y:0};map.focus({preventScroll:true});ev.preventDefault();return;}
    if(key==='['||key===']'){const now=nearChapter().i;visit((now+(key===']'?1:19))%20);ev.preventDefault();return;}
    if(key==='e'&&ev.target===map){const near=nearChapter(); if(near.d<6)openChapter(near.i);ev.preventDefault();return;}
    if(key==='escape'&&!nav.hidden){toggle(false);ev.preventDefault();return;}
  },true);
  document.addEventListener('keyup',ev=>{held.delete(ev.key.toLowerCase());},true);
  window.addEventListener('blur',()=>held.clear());
  document.addEventListener('visibilitychange',()=>{if(document.hidden)held.clear();});
  function tick(t){let dt=last?Math.min(.07,(t-last)/1000):0;last=t;
    let dx=0,dy=0;for(const k of held){if(arrow[k]){dx+=arrow[k][0];dy+=arrow[k][1];}}
    if(dx||dy){const norm=Math.hypot(dx,dy);move(dx/norm*5.2*dt,dy/norm*5.2*dt);}
    requestAnimationFrame(tick);
  }requestAnimationFrame(tick);
  // Pointer dragging pans the camera. A stationary click retains existing click-to-visit behaviour.
  map.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;drag={id:ev.pointerId,x:ev.clientX,y:ev.clientY,moved:false};},true);
  map.addEventListener('pointermove',ev=>{
    if(!drag||ev.pointerId!==drag.id)return;
    const dx=ev.clientX-drag.x,dy=ev.clientY-drag.y;
    if(Math.hypot(dx,dy)>1){drag.moved=true;pan(dx*W/map.getBoundingClientRect().width,dy*H/map.getBoundingClientRect().height);drag.x=ev.clientX;drag.y=ev.clientY;ev.preventDefault();ev.stopImmediatePropagation();}
  },true);
  map.addEventListener('pointerup',ev=>{if(drag&&drag.id===ev.pointerId){skipClick=drag.moved;drag=null;}},true);
  map.addEventListener('pointercancel',()=>{drag=null;},true);
  map.addEventListener('click',ev=>{if(skipClick){skipClick=false;ev.stopImmediatePropagation();ev.preventDefault();}},true);
  // Onscreen arrows continue moving while held, retaining their original single-click action.
  let buttonHeld=null;
  document.querySelectorAll('[data-move]').forEach(btn=>{
    btn.addEventListener('pointerdown',ev=>{if(ev.pointerType==='mouse'&&ev.button!==0)return;buttonHeld={btn,at:performance.now(),last:performance.now()};});
    btn.addEventListener('pointerup',()=>{buttonHeld=null;});
    btn.addEventListener('pointercancel',()=>{buttonHeld=null;});
  });
  window.addEventListener('pointerup',()=>{buttonHeld=null;});
  function holdButtons(t){if(buttonHeld&&t-buttonHeld.at>180){const v=buttonHeld.btn.dataset.move,ds={up:[-1,0],down:[1,0],left:[0,1],right:[0,-1]}[v];if(ds){let dt=Math.min(.065,(t-buttonHeld.last)/1000);move(ds[0]*5*dt,ds[1]*5*dt);}buttonHeld.last=t;}requestAnimationFrame(holdButtons);}requestAnimationFrame(holdButtons);
  window.researchGardenVisit=visit;
})();
