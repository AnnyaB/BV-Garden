"""Distinct, hand-authored pixel fan-art companions for an existing voxel research game.

Only redraw fifteen supporting figures and one in-universe stuffed creature.
Original four lead sprites and the blue-sweater player are never modified.
This is original interpretative fan art, NOT official licensed sprites or models.
"""
from PIL import Image, ImageDraw
from pathlib import Path
import math

DEST=Path(__file__).resolve().parent/'assets'
DEST.mkdir(exist_ok=True)
W,H=96,150
O='#292630';SKIN='#f8d9be';SHADE='#e4ae99';LIT='#fff3d5'

def rgb(s):
 s=s.lstrip('#');return tuple(int(s[i:i+2],16) for i in (0,2,4))
def mix(a,b,t):
 x,y=rgb(a),rgb(b);return '#%02x%02x%02x'%tuple(int(min(255,max(0,x[i]*(1-t)+y[i]*t))) for i in range(3))
class Painter:
 def __init__(self,name):
  self.name=name;self.im=Image.new('RGBA',(W,H));self.d=ImageDraw.Draw(self.im,'RGBA')
 def poly(self,xy,fill,outline=O,width=2):
  self.d.polygon(xy,fill=fill)
  if outline:self.d.line([*xy,xy[0]],fill=outline,width=width,joint='curve')
 def oval(self,xy,fill,outline=O,width=2):self.d.ellipse(xy,fill=fill,outline=outline,width=width if outline else 1)
 def rect(self,xy,fill,outline=None,width=1):self.d.rectangle(xy,fill=fill,outline=outline,width=width)
 def line(self,xy,col,width=2):self.d.line(xy,fill=col,width=width,joint='curve')
 def dot(self,x,y,col,w=2):self.d.rectangle((x,y,x+w,y+w),fill=col)
 def save(self):
  self.im.save(DEST/(self.name+'.png'))

def bodylegs(p,short=False,skirt=False,legcol='#41404e'):
 y=109 if not short else 104
 if skirt:
  p.poly([(32,y-6),(65,y-6),(69,y+10),(29,y+11)],'#3a3444')
 else:
  p.poly([(32,y-4),(47,y-4),(46,134),(35,135)],legcol)
  p.poly([(50,y-4),(65,y-4),(63,135),(51,135)],mix(legcol,'#111522',.12))
 for (x,yy) in ((35,133),(52,133)):
  p.oval((x-6,yy,x+10,yy+9),'#302c3c')
  p.rect((x-2,yy+5,x+7,yy+6),'#6b6068')

def torso(p,color,accent,skirt=False,short=False,arms='relaxed',coat=False):
 bodylegs(p,short,skirt, mix(color,'#20212b',.25))
 sy=81 if short else 78
 p.poly([(34,sy),(55,sy-3),(68,sy+9),(67,111),(29,111),(28,sy+9)],color)
 p.poly([(49,sy-2),(57,sy-2),(64,sy+9),(63,109),(53,110)],mix(color,'#fff4e2',.15),None)
 if coat:
  p.poly([(33,sy+2),(27,111),(39,112),(47,94)],mix(color,'#171925',.14),None)
  p.poly([(56,sy),(68,111),(57,113),(49,95)],mix(color,'#ffffff',.11),None)
 p.poly([(39,sy),(48,sy+10),(56,sy-1)],'#efe8d9',None)
 p.poly([(47,sy+6),(52,sy+7),(51,100),(47,104),(45,99)],accent,None)
 if arms=='relaxed':
  p.poly([(34,sy+2),(26,sy+10),(27,106),(35,108),(39,91)],color)
  p.poly([(64,sy+3),(70,sy+12),(68,107),(60,109),(57,91)],color)
  p.oval((27,103,35,114),SKIN);p.oval((60,104,68,114),SKIN)
 elif arms=='wave':
  p.poly([(34,sy+2),(24,sy-1),(15,sy-19),(10,sy-15),(18,sy+11),(33,sy+19)],color)
  p.oval((8,sy-24,18,sy-13),SKIN)
  p.poly([(62,sy+3),(71,sy+15),(67,104),(60,109),(56,91)],color)
  p.oval((60,104,69,114),SKIN)
 elif arms=='hands':
  p.poly([(34,sy),(25,sy+13),(44,104),(47,97),(37,92)],color)
  p.poly([(61,sy),(69,sy+13),(51,105),(47,98),(57,91)],color)
  p.oval((40,96,52,105),SKIN)
 elif arms=='hip':
  p.poly([(34,sy+3),(25,sy+11),(27,100),(40,105),(44,98),(34,92)],color)
  p.poly([(62,sy+2),(73,sy+8),(65,102),(57,102),(54,96)],color)
  p.oval((62,99,71,108),SKIN)
 if skirt:
  p.poly([(29,106),(67,105),(74,124),(25,124)],mix(color,'#1a1b2a',.17))
  p.poly([(31,109),(45,108),(41,122),(28,122)],mix(color,'#fff1d9',.11),None)
  p.rect((29,123,70,126),accent)

def neck(p):p.rect((44,69,54,81),SKIN)

def head(p,skin=SKIN,face='smile',eye='#677a6e',tilt=0):
 # Large chibi head in three-quarter view with highlight and jaw contour
 p.oval((23,24,74,79),skin)
 p.poly([(24,45),(24,58),(31,73),(44,80),(58,75),(70,61),(70,49),(63,71),(50,77),(34,72)],mix(skin,SHADE,.2),None)
 p.oval((29,40,35,57),mix(skin,'#d89c99',.37))
 p.oval((66,40,73,57),mix(skin,'#d89c99',.28))
 p.oval((30,44,34,54),mix(skin,LIT,.28),None)
 # eyes, pupils and catchlights
 for x,y in [(37,49),(57,47)]:
  p.oval((x-5,y-7,x+4,y+6),'#fef6e6',O,2)
  p.oval((x-2,y-4,x+2,y+4),eye,None)
  p.dot(x,y-4,'#fffef4',2)
  p.line([(x-5,y-9),(x+4,y-10)],'#2e2931',2)
 p.dot(32,62,'#eeadad',2);p.dot(62,60,'#eeadad',2)
 p.dot(49,59,mix(skin,SHADE,.8),2)
 if face=='grin':p.line([(45,66),(49,70),(56,66)],'#925e5d',2)
 elif face=='stern':p.line([(46,68),(54,67)],'#865f65',2)
 elif face=='smirk':p.line([(46,69),(54,65)],'#985e5f',2)
 elif face=='blank':p.line([(47,68),(53,68)],'#9d7773',1)
 else:p.line([(45,66),(49,69),(54,66)],'#965d62',2)

def lock(p,side,col,y0=22,length=62):
 x=20 if side=='L' else 72
 p.poly([(x-5,y0),(x+1,y0+6),(x+3,y0+length-12),(x-1,y0+length),(x-10,y0+length-6),(x-6,y0+17)],col)
 p.line([(x-6,y0+10),(x-7,y0+length-13)],mix(col,'#fff6e5',.24),2)

def bangs(p,col,kind='parted'):
 hi=mix(col,'#f4e8d4',.25)
 if kind=='parted':
  p.poly([(22,43),(23,24),(31,15),(56,13),(72,25),(73,43),(65,37),(57,24),(50,39),(43,28),(35,42)],col)
  p.line([(28,21),(39,17),(54,19)],hi,3)
 elif kind=='spiky':
  p.poly([(21,40),(17,24),(26,25),(26,12),(40,21),(49,9),(56,18),(67,11),(75,29),(71,42),(62,28),(57,36),(46,26),(34,39)],col)
  p.line([(34,21),(43,25),(51,17)],hi,3)
 elif kind=='sweep':
  p.poly([(22,47),(22,29),(31,16),(62,14),(72,26),(71,50),(62,42),(57,29),(44,30),(34,42),(27,50)],col)
  p.poly([(28,31),(35,19),(61,19),(47,30),(31,42)],hi,None)
 elif kind=='bowl':
  p.poly([(20,46),(20,26),(31,17),(62,16),(74,27),(72,45),(64,39),(58,29),(44,34),(32,37),(24,44)],col)
  p.line([(29,24),(44,20),(62,24)],hi,2)
 elif kind=='short':
  p.poly([(24,45),(23,27),(34,17),(58,15),(72,25),(67,43),(58,29),(48,35),(34,40)],col)
  p.line([(28,27),(40,19),(56,21)],hi,2)
 elif kind=='fringe':
  p.poly([(22,44),(23,28),(34,14),(59,13),(72,25),(68,51),(55,48),(54,35),(50,42),(43,48),(37,33),(31,49)],col)
  p.line([(33,21),(45,18),(56,21)],hi,2)

def edensuit(p,girl=False,arms='relaxed'):
 torso(p,'#32303b','#e2bb66',girl,True,arms)
 p.rect((34,99,65,101),'#d5aa60')
 if girl:
  for x in range(28,70,6):p.rect((x,121,x+3,124),'#efcc75')
 p.poly([(45,81),(49,87),(54,80)],'#fff4e1',None)
 p.poly([(47,88),(51,89),(50,99),(47,99)],'#c84f59',None)
 p.rect((57,90,63,94),'#9a4450');p.dot(58,91,'#edd493',2)

def schoolkid(name,hair,eye='#577c66',kind='sweep',arms='relaxed'):
 p=Painter(name)
 # All hair silhouettes differentiated with character signatures
 if name=='becky':
  for x in (11,72):
   p.oval((x-8,27,x+10,62),'#42313c');p.oval((x-5,34,x+9,65),'#554049',None)
  for x in (12,75):p.oval((x-8,31,x+9,41),'#f7f0e2');p.oval((x-5,34,x+6,40),'#d6c7b9',None)
 else:
  p.oval((22,17,72,69),hair)
 edensuit(p,name=='becky',arms)
 neck(p);head(p,face={'damian':'smirk','emile':'grin','ewen':'grin','demetrius':'blank','becky':'smile'}.get(name,'smile'),eye=eye)
 bangs(p,hair,kind)
 if name=='becky':
  p.rect((28,25,37,29),'#e0b767');p.dot(33,23,'#fff1b5',2)
  p.oval((18,50,23,60),mix(hair,'#d3b5b5',.35))
 if name=='damian':
  p.line([(35,44),(41,42)],'#514044',2);p.line([(54,40),(59,40)],'#514044',2)
  p.oval((60,58,63,62),'#e4a7a5',None)
 if name=='emile':
  p.oval((42,66,53,71),'#fdf1e2',None);p.line([(43,67),(52,67)],'#8b5a4b',2)
 if name=='ewen':
  p.poly([(23,27),(29,13),(38,18),(46,10),(57,18),(66,13),(72,24)],hair)
  p.line([(29,23),(37,17),(47,20)],mix(hair,'#ffefc0',.45),2)
 if name=='demetrius':
  p.poly([(22,29),(33,18),(53,13),(70,28),(69,47),(56,50),(47,38),(39,54),(29,42)],hair)
  p.line([(37,53),(41,52)],'#4d3c48',2)
 p.save()

def adult(name,hair,clothes,accent,face='smile',eye='#717d80',kind='sweep',hairlong=False,skirt=False,arms='relaxed',coat=True):
 p=Painter(name)
 if hairlong:
  p.poly([(23,27),(33,11),(61,10),(77,27),(78,111),(66,119),(61,72),(32,73),(30,115),(19,116)],hair)
  p.poly([(60,49),(72,62),(70,107),(65,109)],mix(hair,'#f4dbbf',.22),None)
 else:p.oval((22,15,72,74),hair)
 torso(p,clothes,accent,skirt,False,arms,coat)
 neck(p);head(p,face=face,eye=eye)
 bangs(p,hair,kind)
 p.save();return p

# Each companion has its own pose, silhouette and iconic costume cues.
schoolkid('becky','#44333e','#768b79','sweep','wave')
schoolkid('damian','#55413c','#64876b','spiky','hip')
schoolkid('emile','#b6a078','#6e8c72','bowl','hands')
schoolkid('ewen','#cfb179','#667fa2','spiky','wave')
schoolkid('demetrius','#242a34','#7c7f88','fringe','relaxed')

# Historic teacher: high white coiffure, long gray jacket, cane, angular eyebrows.
p=adult('henry','#dfdfd5','#3e4149','#a09da0','stern','#798f8c','sweep',False,False,'relaxed',True)
p.poly([(25,29),(34,15),(54,14),(66,26),(69,36),(56,28),(42,34),(28,38)],'#e9e7df')
p.poly([(44,70),(53,70),(50,88),(46,88)],'#e9e3d5',None)
p.line([(29,50),(40,48)],'#726d70',2);p.line([(53,46),(65,46)],'#726d70',2)
p.poly([(40,68),(46,72),(53,69),(50,77),(45,80)],'#d6d3cd')
p.line([(78,93),(80,138)],'#755b49',3);p.oval((77,88,85,95),'#ba9a73');p.save()

# Franky: amber large glasses, fluffy dark afro, warm shirt, suspenders and tie.
p=adult('franky','#2d2429','#e3d9c3','#b66d41','grin','#608687','bowl',False,False,'wave')
for dx,dy,r in [(21,24,12),(34,11,13),(52,9,14),(67,16,13),(76,29,11),(13,36,11)]:p.oval((dx-r,dy-r,dx+r,dy+r),'#2f292d')
for dx,dy,r in [(21,25,7),(34,12,8),(53,10,9),(67,17,8)]:p.oval((dx-r,dy-r,dx+r,dy+r),'#4a3841',None)
for x in (31,53):p.rect((x-6,41,x+7,55),'#f3cf84','#763f33',2)
p.line([(44,47),(48,47)],'#924d36',2);p.rect((32,82,35,103),'#8c5945');p.rect((61,82,64,103),'#8c5945');p.save()

# Yuri: sharp raven hair, black formal uniform, dark blue tie, strict expression.
p=adult('yuri','#283039','#3c4c48','#b7c1ac','stern','#ab5c61','fringe',False,False,'relaxed')
p.poly([(39,80),(49,91),(59,79)],'#f6eadb',None)
p.poly([(47,88),(52,88),(52,106),(47,107)],'#32445d',None)
p.rect((61,83,66,88),'#d0ab68');p.save()

# Sylvia: recognizable wide purple-banded hat, chestnut-orange long curls, glasses, black dress.
p=adult('sylvia','#a96146','#34303b','#dad5cc','stern','#7e7a7b','parted',True,True,'hip')
for x in (20,70):
 p.poly([(x-3,61),(x+4,54),(x+6,77),(x+1,87),(x+6,99)],'#a96146')
 p.line([(x,65),(x+1,78),(x,85)],'#e18d64',2)
p.oval((28,43,45,56),'#fcf6ec','#67606a',2);p.oval((53,41,68,55),'#fcf6ec','#67606a',2)
p.line([(45,48),(54,47)],'#77707a',2)
p.poly([(22,21),(30,13),(59,13),(69,19),(67,26),(20,28)],'#35303a')
p.poly([(6,23),(27,20),(63,19),(88,25),(85,29),(9,30)],'#332c36')
p.line([(13,25),(75,25)],'#96516a',4)
p.poly([(40,83),(48,92),(56,81),(52,101),(48,104),(43,96)],'#f2ede8',None)
p.save()

# Nightfall: silver asymmetric over-eye fringe and tailored navy double-breasted coat.
p=adult('fiona','#d8d8e1','#2c4162','#a99a8f','blank','#647587','sweep',False,False,'relaxed')
p.poly([(28,26),(36,14),(65,15),(70,29),(62,52),(49,60),(40,50),(47,29)],'#e1e1ea')
p.poly([(37,27),(65,18),(56,43),(44,51)],'#f0eff0',None)
p.poly([(20,55),(27,69),(32,69)],'#d2cedc')
for x,y in [(38,91),(56,91),(37,102),(55,102)]:p.oval((x,y,x+4,y+4),'#d3b676',None)
p.line([(33,116),(40,120)],'#667390',2);p.save()

# Martha: short silver curls, prominent swept bun and formal pendant.
p=adult('martha','#c8c8cb','#364053','#d0ae71','smile','#737b83','parted',False,False,'hands')
p.oval((67,25,86,48),'#bfc0c5');p.oval((71,30,84,45),'#e2dfe2',None)
p.poly([(22,25),(28,14),(51,14),(62,25),(39,39)],'#e2e0de')
p.oval((43,79,57,91),'#e1c88a');p.oval((46,80,54,88),'#fff0b5',None)
p.save()

# Melinda: dark chestnut long locks, white ivory blouse, dark navy skirt.
p=adult('melinda','#45353f','#f3ede3','#d6b993','smile','#a87986','parted',True,True,'hands')
p.poly([(24,43),(21,65),(20,108),(31,118),(34,78),(32,52)],'#47333d')
p.poly([(68,42),(75,63),(78,106),(68,117),(64,74),(65,53)],'#47333d')
p.poly([(29,109),(67,108),(72,124),(26,125)],'#34425c')
p.poly([(40,78),(49,86),(56,78)],'#fff9f2',None)
p.save()

# Donovan: severe upstanding dark hair and long tan double-breasted coat, facial side scars.
p=adult('donovan','#32323a','#a99a85','#6c6057','stern','#88818c','spiky',False,False,'relaxed',True)
p.poly([(20,30),(23,11),(33,15),(41,7),(50,15),(60,10),(69,26),(68,40),(56,28),(44,24),(31,34)],'#302f38')
p.line([(29,16),(39,14),(51,18)],'#5a5860',3)
p.line([(27,38),(29,43),(26,48)],'#b36a70',2);p.line([(66,40),(63,45),(66,51)],'#b46b70',2)
for y in (95,103,110):p.dot(40,y,'#6d554d',2);p.dot(59,y,'#6d554d',2)
p.save()

# Camilla: golden high side ponytail, rose knit, dark skirt and earrings.
p=adult('camilla','#d4b16e','#bd7b84','#e0a9a3','smirk','#98869e','parted',False,True,'hip')
p.oval((67,15,84,49),'#e4c77c');p.poly([(75,35),(85,46),(80,69),(70,79),(72,48)],'#d8b46f')
p.line([(73,23),(80,35),(79,48)],'#fff2bc',2)
p.oval((26,51,30,56),'#f4d582',None);p.oval((70,49,75,55),'#f4d582',None)
p.poly([(33,84),(46,87),(56,83)],'#efc0b5',None)
p.save()

# Shopkeeper: full desert head covering and shaded face / scarf from series design.
p=Painter('shopkeeper')
p.poly([(18,14),(29,9),(61,10),(76,20),(72,88),(66,100),(61,65),(31,65),(25,107),(18,90)],'#dbd0ad')
p.poly([(30,18),(64,19),(75,32),(19,33)],'#aa9a74',None)
torso(p,'#ded8c5','#c18b4e',False,False,'relaxed')
neck(p);head(p,skin='#afaa9f',face='blank',eye='#817c78')
p.poly([(16,18),(29,8),(62,8),(78,23),(77,39),(15,39)],'#c8bd91')
p.poly([(19,34),(78,34),(82,42),(16,43)],'#9f9374')
p.rect((29,45,65,53),'#5c5455');p.rect((33,47,61,49),'#827779')
p.poly([(24,57),(67,57),(69,80),(28,82)],'#807b6f')
p.line([(43,83),(48,92),(51,102)],'#9f7653',3);p.save()

# Mr Chimera: deliberately a PLUSH, not a human; pink round face, mint-green hood,
# pointed ears/horns, green wings, round paws and curled tail.
p=Painter('chimera')
p.poly([(22,52),(12,26),(29,35),(34,17),(43,35),(57,23),(66,32),(78,19),(79,57)],'#4a876c')
p.poly([(20,69),(6,77),(20,92),(28,88),(28,111),(69,114),(76,91),(88,79),(75,73)],'#438c73')
p.oval((28,68,70,119),'#dd9a9e')
p.oval((22,32,77,83),'#66b090')
p.oval((26,40,73,78),'#e9aca9')
p.oval((37,54,42,60),'#342e43');p.oval((60,54,65,60),'#342e43')
p.oval((42,61,58,73),'#f1dabe');p.oval((47,64,53,69),'#53434c',None)
p.oval((26,107,43,126),'#4a967f');p.oval((60,106,76,125),'#4a967f')
p.poly([(21,78),(8,70),(9,92),(29,98)],'#73baa0')
p.poly([(75,77),(89,68),(90,89),(71,99)],'#73baa0')
p.line([(77,111),(87,126),(80,136),(73,133)],'#468d74',6)
p.oval((35,78,63,110),'#f3b6b1',None)
p.save()

if __name__=='__main__':pass
print('Built 16 individualized 96×150 sprite illustrations; principal original four and explorer unchanged.')
