/* THE LATENT ATLAS — real WebGL 3D voxel garden. Offline, no libraries or API calls.
   Scientific UI and chapter locks remain controlled by game.js. */
(()=>{
'use strict';
const host=document.querySelector('.canvas-wrap');if(!host||typeof chapters==='undefined')return;
const canvas3=document.createElement('canvas');canvas3.id='world3d';canvas3.width=1070;canvas3.height=626;canvas3.tabIndex=0;
canvas3.setAttribute('aria-label','Interactive WebGL 3D research garden. Drag to orbit, scroll to zoom, use WASD or arrows to walk, tap pixel companions to open their strictly ordered scientific chapters.');
host.insertBefore(canvas3,host.firstChild);
const gl=canvas3.getContext('webgl',{alpha:false,antialias:false,depth:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
if(!gl){canvas3.remove();return;}
const base=document.getElementById('world');base.style.display='none';
const overlay=document.createElement('div');overlay.id='voxelLabels';host.appendChild(overlay);
const actions=document.createElement('div');actions.className='voxel-actions';actions.innerHTML='<button type="button" id="orbitReset" title="Return to your explorer">◈ Follow</button><button type="button" id="mapOverview" title="See the whole research garden">▦ Map</button><button type="button" id="voxelZoomIn" aria-label="Zoom in">＋</button><button type="button" id="voxelZoomOut" aria-label="Zoom out">－</button>';
host.appendChild(actions);
const hint=document.createElement('div');hint.id='orbitHint';hint.textContent='DRAG TO ROTATE · SCROLL TO ZOOM · TAP COMPANIONS';host.appendChild(hint);
const W=canvas3.width,H=canvas3.height;
function shader(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
function program(vs,fs){const p=gl.createProgram();gl.attachShader(p,shader(gl.VERTEX_SHADER,vs));gl.attachShader(p,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p;}
const solid=program('attribute vec3 a;attribute vec3 c;uniform mat4 m;varying vec3 color;void main(){color=c;gl_Position=m*vec4(a,1.);}',
'precision mediump float;varying vec3 color;void main(){gl_FragColor=vec4(color,1.);}');
const tex=program('attribute vec3 a;attribute vec2 uv;uniform mat4 m;varying vec2 v;void main(){v=uv;gl_Position=m*vec4(a,1.);}',
'precision mediump float;varying vec2 v;uniform sampler2D sprite;void main(){vec4 col=texture2D(sprite,v);if(col.a<0.35)discard;gl_FragColor=col;}');
const solidA=gl.getAttribLocation(solid,'a'),solidC=gl.getAttribLocation(solid,'c'),solidM=gl.getUniformLocation(solid,'m');
const texA=gl.getAttribLocation(tex,'a'),texUV=gl.getAttribLocation(tex,'uv'),texM=gl.getUniformLocation(tex,'m');
const geo=[],colors=[];
function rgb(hex,s=1){hex=hex.replace('#','').slice(0,6);const a=[0,2,4].map(i=>parseInt(hex.slice(i,i+2),16)/255);return a.map(v=>Math.max(0,Math.min(1,v*s)));}
function face(v,shade,col){const cc=rgb(col,shade);for(const q of [v[0],v[1],v[2],v[0],v[2],v[3]]){geo.push(...q);colors.push(...cc);}}
function cube(x,y,z,w,h,d,col){const x0=x-w/2,x1=x+w/2,y0=y-h/2,y1=y+h/2,z0=z-d/2,z1=z+d/2;
 const p={a:[x0,y0,z0],b:[x1,y0,z0],c:[x1,y1,z0],d:[x0,y1,z0],e:[x0,y0,z1],f:[x1,y0,z1],g:[x1,y1,z1],h:[x0,y1,z1]};
 face([p.a,p.b,p.c,p.d],.68,col);face([p.e,p.f,p.g,p.h],.96,col);face([p.d,p.c,p.g,p.h],1.19,col);face([p.a,p.b,p.f,p.e],.55,col);face([p.a,p.e,p.h,p.d],.78,col);face([p.b,p.f,p.g,p.c],.86,col);
}
function confetti(x,y,z,color){cube(x,y,z,.18,.15,.15,color);}
function rand(i,j){let n=((i*374761393+j*668265263)^1234567)|0;n=Math.imul(n^(n>>>13),1274126177);return((n^(n>>>16))>>>0)/4294967295;}
function minPathDistance(x,z){let md=999;
 for(let i=0;i<chapters.length-1;i++){const a=chapters[i].place,b=chapters[i+1].place,dx=b[0]-a[0],dz=b[1]-a[1],t=Math.max(0,Math.min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz||1)));md=Math.min(md,Math.hypot(x-a[0]-t*dx,z-a[1]-t*dz));}
 return md;
}
function tree(x,z,seed){const pink=seed>.7,leaf=pink?'#d78c9c':'#4d8f77',light=pink?'#f7bed0':'#8dbb90';
 cube(x,1.07,z,.43,2.15,.43,'#8c6850');cube(x+.12,1.52,z-.14,.19,.8,.18,'#b38b60');
 for(let h=0;h<3;h++){
  const rad=1.28-h*.25;cube(x,2.2+h*.49,z,rad*2,.58,rad*2,h===2?light:leaf);
  cube(x-.35,2.1+h*.45,z+.34,rad*1.2,.35,rad*.95,h===2?leaf:light);
 }
 for(let a=0;a<6;a++){const t=a*2.4,dx=Math.sin(t+seed*9)*.95,dz=Math.cos(t+seed*8)*.95;confetti(x+dx,2.37+(a%3)*.42,z+dz,pink?'#ffe0d8':'#cee3ad');}
}
function bench(x,z){cube(x,.3,z,1.85,.2,.62,'#a6785d');cube(x,.69,z-.24,1.85,.8,.18,'#be916f');cube(x-.65,.1,z,.18,.48,.4,'#52564c');cube(x+.65,.1,z,.18,.48,.4,'#52564c');}
function lantern(x,z){cube(x,.6,z,.12,1.3,.12,'#5b6960');cube(x,1.3,z,.38,.45,.38,'#f6db95');cube(x,1.55,z,.52,.13,.52,'#555c61');cube(x,1.3,z,.4,.07,.4,'#fff5bd');}
function house(ch){const [x,z]=ch.place,c=ch.color;
 // shallow 3D terrace
 cube(x,.12,z,4.0,.24,3.65,'#b6a590');cube(x,.83,z,3.4,1.45,3,'#ede0c7');cube(x,1.72,z,3.75,.25,3.24,'#b39e8f');
 // thick voxel roof in receding layers, overhang / skylights
 for(let i=0;i<6;i++){const shrink=i*.32;cube(x,1.94+i*.23,z,4.15-shrink,.25,3.7-shrink,c);}
 cube(x+1.2,2.62,z-.7,.35,.95,.48,'#a3786c');cube(x+1.2,3.12,z-.7,.55,.15,.65,'#8b6259');
 // front wooden door, warm glazed windows on several faces
 cube(x, .75,z+1.56,.74,1.35,.09,'#846958');cube(x,.8,z+1.62,.52,1.03,.09,'#5a7668');
 cube(x+.16,.82,z+1.69,.055,.07,.05,'#f4d494');
 for(const dx of [-1.1,1.1]){cube(x+dx,1.05,z+1.57,.64,.7,.1,'#775c52');cube(x+dx,1.06,z+1.63,.49,.52,.05,'#ffd89e');cube(x+dx,1.07,z+1.68,.04,.52,.03,'#7e6255');cube(x+dx,1.07,z+1.68,.45,.035,.03,'#7e6255');}
 for(const dz of [-.75,.75]){cube(x+1.73,1.03,z+dz,.09,.71,.7,'#715b52');cube(x+1.79,1.05,z+dz,.05,.52,.5,'#ffe9b2');}
 // curved-style garden boxes and little research lamp
 cube(x-1.65,.18,z+1.95,.53,.4,.37,'#8e755b');cube(x+1.57,.18,z+1.95,.5,.4,.37,'#8e755b');
 for(let j=0;j<4;j++){const xx=x-1.82+j*.14;cube(xx,.48,z+1.95,.23,.22,.23,j%2?'#81b78f':'#e7a1b1');}
 lantern(x+2,z+1.1);
 // level pedestal for companion at front right; stone slab with trim
 const px=x+2.55,pz=z-.8;
 cube(px,.07,pz,1.55,.16,1.45,'#d0c0a5');cube(px,.17,pz,1.23,.11,1.23,'#efe6d6');
 cube(px,.03,pz+1.03,.48,.13,.58,'#dfcfb6');
 // numbered path stepping stones
 for(let k=0;k<3;k++)cube(x-.9+k*.5,.04,z+2.1+k*.31,.45,.08,.45,'#e8cfab');
}
// 3D scene generation. World is spatially accurate: all visible props are real 3D geometry.
cube(19,-.64,19,42,1.28,42,'#699a75');cube(19,-1.36,19,43,.18,43,'#597c66');
for(let x=0;x<39;x++)for(let z=0;z<39;z++){
 const r=rand(x+2,z+5),edge=x===0||z===0||x===38||z===38;
 if(edge&&r>.24){cube(x,.4,z,.17,.9,.17,'#ddd1aa');continue;}
 if(r>.89)cube(x,.055,z,.7,.095,.7,r>.955?'#9ccc97':'#7fae87');
 if(r>.69&&r<.72&&minPathDistance(x,z)>2.4){cube(x,.12,z,.08,.28,.07,'#549764');confetti(x,.28,z,r>.705?'#fff2cf':'#f2a6c3');}
}
for(let i=0;i<chapters.length-1;i++){
 const a=chapters[i].place,b=chapters[i+1].place,dx=b[0]-a[0],dz=b[1]-a[1],len=Math.hypot(dx,dz),steps=Math.floor(len*3);
 for(let k=0;k<=steps;k++){const t=k/steps,x=a[0]+dx*t,z=a[1]+dz*t;
  cube(x,.08,z,.44,.12,.44,(k%3===0?'#f7e7b9':'#e6d5b1'));
  if(k%13===8)cube(x,.14,z,.15,.17,.16,'#ecc488');
 }
}
for(let x=2;x<=37;x+=2.2)for(let z=2;z<=37;z+=2.3){const r=rand(Math.floor(x*13),Math.floor(z*7));
 if(chapters.some(c=>Math.hypot(x-c.place[0],z-c.place[1])<3.7)||minPathDistance(x,z)<1.35||Math.hypot(x-21,z-21)<3.5)continue;
 if(r>.79)tree(x,z,r);else if(r>.62){cube(x,.25,z,.75,.5,.83,'#669b6d');cube(x,.54,z,.65,.3,.64,r>.71?'#d7b4c5':'#a0cb99');}
 else if(r>.44){cube(x,.12,z,.10,.24,.1,'#4b9276');confetti(x,.30,z,r>.53?'#f4bdce':'#f8da95');}
}
chapters.forEach(house);
// special fountain and a little reading plaza: volumetric, not a background illustration
cube(21,.12,21,4.5,.24,4.5,'#e6d7c6');cube(21,.24,21,3.15,.4,3.15,'#a8cfce');cube(21,.44,21,2.75,.16,2.75,'#6ea9bf');
cube(21,.9,21,.48,1.45,.48,'#d0e1d5');cube(21,1.48,21,1.6,.17,1.6,'#d6e2d9');cube(21,1.6,21,1.3,.15,1.3,'#7ab5cb');
for(let j=0;j<8;j++){const a=j*Math.PI/4;confetti(21+Math.sin(a)*1.6,.52,21+Math.cos(a)*1.6,'#f1eada');}
bench(17.3,20.5);bench(24.7,20.3);lantern(18.7,23);lantern(23.3,24);
for(let x=1;x<38;x+=3){cube(x,.28,0.5,.17,.56,.15,'#d9c9a6');cube(x,.28,37.5,.17,.56,.15,'#d9c9a6');}
for(let z=1;z<38;z+=3){cube(.5,.28,z,.15,.56,.17,'#d9c9a6');cube(37.5,.28,z,.15,.56,.17,'#d9c9a6');}
const vertexBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vertexBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(geo),gl.STATIC_DRAW);
const colorBuf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,colorBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(colors),gl.STATIC_DRAW);
const totalVerts=geo.length/3;
const spriteVertices=gl.createBuffer(),spriteUvs=gl.createBuffer();
const TEX_COORDS=new Float32Array([0,1,1,1,1,0, 0,1,1,0,0,0]);
gl.bindBuffer(gl.ARRAY_BUFFER,spriteUvs);gl.bufferData(gl.ARRAY_BUFFER,TEX_COORDS,gl.STATIC_DRAW);
const textures={};
const texReady={};
for(const id of [...IDS,'explorer','stella','tonitrus']){let im=imgs[id];
 const t=gl.createTexture();textures[id]=t;
 gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,245,219,255]));
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);
 gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
 function update(){if(!im.complete||!im.naturalWidth)return;gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,im);texReady[id]=true;}
 im.addEventListener('load',update);update();
}
// Each supporting figure is a separate *volumetric* color-voxel character.
// The user's explorer remains a movable textured character; this does not use
// third-party 3D libraries and is not a flat pre-rendered image of the garden.
const voxelCast={ready:false,vertexCount:0,pixelSize:0,mode:'3D extruded pixel-volume figures'};
function prepareVolumetricCast(){
 if(voxelCast.ready||!IDS.every(id=>imgs[id].complete&&imgs[id].naturalWidth>0))return;
 const vg=[],vc=[],N=42,M=62;
 const shade=(r,g,b,k)=>[r/255*k,g/255*k,b/255*k].map(v=>Math.max(0,Math.min(1,v)));
 function quad(a,b,c,d,col,brightness){
  const rgb=shade(col[0],col[1],col[2],brightness);
  for(const v of [a,b,c,a,c,d]){vg.push(...v);vc.push(...rgb);}
 }
 for(const ch of chapters){
  const im=imgs[ch.id];const off=document.createElement('canvas');off.width=N;off.height=M;
  const c=off.getContext('2d',{willReadFrequently:true});c.imageSmoothingEnabled=false;
  // Crop transparent padding but NEVER alter the art or use synthetic stand-ins.
  const scan=document.createElement('canvas');scan.width=im.naturalWidth;scan.height=im.naturalHeight;
  const scanCtx=scan.getContext('2d',{willReadFrequently:true});scanCtx.drawImage(im,0,0);
  const raw=scanCtx.getImageData(0,0,scan.width,scan.height).data;
  let left=scan.width,top=scan.height,right=0,bottom=0;
  for(let j=0;j<scan.height;j++)for(let i=0;i<scan.width;i++)if(raw[(j*scan.width+i)*4+3]>40){left=Math.min(left,i);right=Math.max(right,i);top=Math.min(top,j);bottom=Math.max(bottom,j);}
  if(right<=left||bottom<=top)continue;
  const srcW=right-left+1,srcH=bottom-top+1;
  // Center the character, preserving real silhouette proportions.
  const scale=Math.min((N-3)/srcW,(M-3)/srcH);
  const drawW=Math.max(1,Math.round(srcW*scale)),drawH=Math.max(1,Math.round(srcH*scale));
  c.drawImage(im,left,top,srcW,srcH,Math.round((N-drawW)/2),M-drawH,drawW,drawH);
  const buf=c.getImageData(0,0,N,M).data;
  const occupied=(i,j)=>i>=0&&j>=0&&i<N&&j<M&&buf[(j*N+i)*4+3]>80;
  const H=ch.id==='bond'?2.15:ch.id==='chimera'?1.85:2.7;
  const W=ch.id==='bond'?2.60:ch.id==='chimera'?1.7:1.87;
  const py=H/M,px=W/N,centerX=ch.place[0]+2.55,centerZ=ch.place[1]-.8;
  for(let j=0;j<M;j++)for(let i=0;i<N;i++){
   if(!occupied(i,j))continue;
   const k=(j*N+i)*4,col=[buf[k],buf[k+1],buf[k+2]];
   const x0=centerX+(i-N/2)*px,x1=x0+px;
   const y0=.23+(M-j-1)*py,y1=y0+py;
   // Head and body have different actual depths, giving camera-visible thickness.
   const head=j/M<.54,thickness=(head?.25:.18)+.06*(1-Math.abs(i-N*.5)/(N*.5));
   const front=centerZ-thickness,back=centerZ+thickness;
   quad([x0,y0,front],[x1,y0,front],[x1,y1,front],[x0,y1,front],col,1.06);
   quad([x1,y0,back],[x0,y0,back],[x0,y1,back],[x1,y1,back],col,.72);
   if(!occupied(i-1,j))quad([x0,y0,back],[x0,y0,front],[x0,y1,front],[x0,y1,back],col,.68);
   if(!occupied(i+1,j))quad([x1,y0,front],[x1,y0,back],[x1,y1,back],[x1,y1,front],col,.83);
   if(!occupied(i,j-1))quad([x0,y1,front],[x1,y1,front],[x1,y1,back],[x0,y1,back],col,1.15);
   if(!occupied(i,j+1))quad([x0,y0,back],[x1,y0,back],[x1,y0,front],[x0,y0,front],col,.56);
  }
 }
 if(vg.length===0)return;
 voxelCast.positionBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,voxelCast.positionBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vg),gl.STATIC_DRAW);
 voxelCast.colorBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,voxelCast.colorBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vc),gl.STATIC_DRAW);
 voxelCast.vertexCount=vg.length/3;voxelCast.ready=true;
}
for(const id of IDS){imgs[id].addEventListener('load',prepareVolumetricCast);}
prepareVolumetricCast();

function mul(A,B){const O=new Float32Array(16);for(let col=0;col<4;col++)for(let row=0;row<4;row++){let s=0;for(let k=0;k<4;k++)s+=A[k*4+row]*B[col*4+k];O[col*4+row]=s;}return O;}
function perspective(fovy,aspect,n,f){let y=1/Math.tan(fovy/2);return new Float32Array([y/aspect,0,0,0,0,y,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]);}
function norm(v){const l=Math.hypot(...v)||1;return v.map(a=>a/l);}
function cross(a,b){return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
function lookAt(eye,target){const z=norm(eye.map((v,i)=>v-target[i])),x=norm(cross([0,1,0],z)),y=cross(z,x);return new Float32Array([x[0],y[0],z[0],0, x[1],y[1],z[1],0, x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]);}
function project(x,y,z,mat){const q=[x,y,z,1],o=[0,0,0,0];for(let row=0;row<4;row++){for(let col=0;col<4;col++)o[row]+=mat[col*4+row]*q[col];}if(o[3]<=.01)return {visible:false};const sx=(o[0]/o[3]*.5+.5)*W,sy=(.5-o[1]/o[3]*.5)*H;return{x:sx,y:sy,depth:o[2]/o[3],visible:sx>-130&&sx<W+130&&sy>-130&&sy<H+130};}
let yaw=-.85,pitch=.72,distance=24,follow=true,overview=false,drag=false,dragging=false,down=null;
let cameraTarget=[chapters[0].place[0],0,chapters[0].place[1]],currentMvp=null,lastFrame=0;
let pointerGoal=null;
const labelButtons=chapters.map((c,i)=>{const b=document.createElement('button');b.type='button';b.className='voxel-label';b.dataset.chapter=i;b.setAttribute('aria-label',`Open chapter ${i+1}: ${c.short}${i>state.current?' locked':''}`);b.innerHTML=`<span class="voxel-label-id">${String(i+1).padStart(2,'0')}</span><span class="voxel-label-text">${c.short}</span>`;overlay.appendChild(b);return b;});
function renderBillboard(id,x,z,h,width,ms){if(!texReady[id])return;
 let bob=Math.sin(ms*.002+id.length)*.055;const right=[-Math.sin(yaw),0,Math.cos(yaw)],xx=x,zz=z;const w=width/2,y0=.22+bob,y1=y0+h;
 // right vector lies in the camera image plane; the sprite is still a 3D object with depth testing.
 const A=[xx-right[0]*w,y0,zz-right[2]*w],B=[xx+right[0]*w,y0,zz+right[2]*w],C=[xx+right[0]*w,y1,zz+right[2]*w],D=[xx-right[0]*w,y1,zz-right[2]*w];
 const data=new Float32Array([...A,...B,...C,...A,...C,...D]);
 gl.bindBuffer(gl.ARRAY_BUFFER,spriteVertices);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STREAM_DRAW);gl.vertexAttribPointer(texA,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,spriteUvs);gl.vertexAttribPointer(texUV,2,gl.FLOAT,false,0,0);
 gl.bindTexture(gl.TEXTURE_2D,textures[id]);gl.drawArrays(gl.TRIANGLES,0,6);
}
function updateLabels(mvp){const px=canvas3.clientWidth/W,py=canvas3.clientHeight/H;
 for(let i=0;i<chapters.length;i++){
  const ch=chapters[i],p=project(ch.place[0],4.1,ch.place[1],mvp),el=labelButtons[i],near=Math.hypot(state.player.x-ch.place[0],state.player.y-ch.place[1]);
  // Keep labels legible: current chapter is always present nearby, other stations appear in their surrounding neighborhood.
  const show=p.visible&&(overview||near<11||i===state.current);
  el.style.display=show?'flex':'none';if(!show)continue;
  el.style.left=(p.x*px)+'px';el.style.top=(p.y*py)+'px';el.classList.toggle('voxel-label-active',i===state.current);
  el.classList.toggle('voxel-label-locked',i>state.current);
  el.classList.toggle('voxel-label-done',i<state.current);
  if(typeof quest!=='undefined')el.style.borderColor=quest.stars[i]?'#d8ae57':i>state.current?'#9e5f65':'';
 }
}
function updateWorld(ms){if(!document.body.contains(canvas3))return;requestAnimationFrame(updateWorld);if(ms-lastFrame<25)return;lastFrame=ms;
 if(pointerGoal&&!state.travel){const dx=pointerGoal.x-state.player.x,dz=pointerGoal.z-state.player.y,len=Math.hypot(dx,dz);if(len<.1)pointerGoal=null;else{const step=Math.min(.2,len);const nx=state.player.x+dx/len*step,nz=state.player.y+dz/len*step;if(typeof canEnterZone==='function'&&!canEnterZone(nx,nz)){pointerGoal=null;if(typeof showRewardToast==='function')showRewardToast('tonitrus','Tonitrus gate · finish the current chapter');}else{state.player.x=nx;state.player.y=nz;}}}
 if(follow){const tx=overview?19:state.player.x,tz=overview?19:state.player.y;
  cameraTarget[0]+=(tx-cameraTarget[0])*.085;cameraTarget[2]+=(tz-cameraTarget[2])*.085;
 }
 const eye=[cameraTarget[0]+distance*Math.cos(yaw)*Math.cos(pitch), cameraTarget[1]+distance*Math.sin(pitch)+2.5,cameraTarget[2]+distance*Math.sin(yaw)*Math.cos(pitch)];
 const vp=mul(perspective(.68,W/H,.1,250),lookAt(eye,[cameraTarget[0],0,cameraTarget[2]]));currentMvp=vp;
 gl.viewport(0,0,W,H);gl.clearColor(.68,.85,.85,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);
 gl.useProgram(solid);gl.uniformMatrix4fv(solidM,false,vp);
 gl.enableVertexAttribArray(solidA);gl.enableVertexAttribArray(solidC);
 gl.bindBuffer(gl.ARRAY_BUFFER,vertexBuf);gl.vertexAttribPointer(solidA,3,gl.FLOAT,false,0,0);
 gl.bindBuffer(gl.ARRAY_BUFFER,colorBuf);gl.vertexAttribPointer(solidC,3,gl.FLOAT,false,0,0);
 gl.drawArrays(gl.TRIANGLES,0,totalVerts);
 // Draw actual 3D-color pixel volumes, with depth testing and side surfaces.
 if(voxelCast.ready){
  gl.bindBuffer(gl.ARRAY_BUFFER,voxelCast.positionBuffer);gl.vertexAttribPointer(solidA,3,gl.FLOAT,false,0,0);
  gl.bindBuffer(gl.ARRAY_BUFFER,voxelCast.colorBuffer);gl.vertexAttribPointer(solidC,3,gl.FLOAT,false,0,0);
  gl.drawArrays(gl.TRIANGLES,0,voxelCast.vertexCount);
 }
 gl.disableVertexAttribArray(solidA);gl.disableVertexAttribArray(solidC);
 gl.useProgram(tex);gl.uniformMatrix4fv(texM,false,vp);gl.enableVertexAttribArray(texA);gl.enableVertexAttribArray(texUV);
 gl.activeTexture(gl.TEXTURE0);gl.uniform1i(gl.getUniformLocation(tex,'sprite'),0);
 const npcs=chapters.map(ch=>({ch, depth:Math.hypot(eye[0]-(ch.place[0]+1.45),eye[2]-(ch.place[1]+2.2))}));
 npcs.push({ch:{id:'explorer',place:[state.player.x-2.55,state.player.y+.8],_you:true},depth:Math.hypot(eye[0]-state.player.x,eye[2]-state.player.y)});
 npcs.sort((a,b)=>b.depth-a.depth);
 for(const e of npcs){const ch=e.ch;if(voxelCast.ready&&!ch._you)continue;renderBillboard(ch.id,ch.place[0]+2.55,ch.place[1]-.8,ch._you?2.7:ch.id==='bond'?2.1:ch.id==='chimera'?1.9:2.6,ch._you?1.8:ch.id==='bond'?2.65:ch.id==='chimera'?1.45:1.75,ms);}
 // Volumetric garden + separately textured, depth-tested pixel award markers on each gated cottage.
 for(const ch of chapters){const badge=typeof quest==='undefined'?null:quest.stars[ch.index]?'stella':ch.index>state.current?'tonitrus':null;
 if(badge)renderBillboard(badge,ch.place[0]+1.65,ch.place[1]-1.9,1.05,.93,ms);}
 for(let i=state.current;i<chapters.length-1;i++){const a=chapters[i].place,b=chapters[i+1].place;renderBillboard('tonitrus',(a[0]+b[0])/2,(a[1]+b[1])/2,1.15,.93,ms);}

 gl.disableVertexAttribArray(texA);gl.disableVertexAttribArray(texUV);
 updateLabels(vp);
}
const startRotation=(ev)=>{drag=true;dragging=false;down={x:ev.clientX,y:ev.clientY,yaw,pitch};canvas3.setPointerCapture(ev.pointerId);};
canvas3.addEventListener('pointerdown',startRotation);
canvas3.addEventListener('pointermove',ev=>{if(!drag||!down)return;const dx=ev.clientX-down.x,dy=ev.clientY-down.y;if(Math.hypot(dx,dy)>6)dragging=true;if(dragging){yaw=down.yaw-dx*.009;pitch=Math.max(.16,Math.min(1.27,down.pitch+dy*.007));}});
canvas3.addEventListener('pointerup',ev=>{
 if(!drag)return;drag=false;if(dragging)return;
 const r=canvas3.getBoundingClientRect(),sx=(ev.clientX-r.left)*W/r.width,sy=(ev.clientY-r.top)*H/r.height;
 let near={i:-1,d:Infinity};for(let i=0;i<chapters.length;i++){const ch=chapters[i];for(const pos of [[ch.place[0]+2.55,1.7,ch.place[1]-.8],[ch.place[0],2.2,ch.place[1]]]){let q=project(...pos,currentMvp);let d=Math.hypot(q.x-sx,q.y-sy);if(q.visible&&d<near.d)near={i,d};}}
 if(near.i>=0&&near.d<55){openChapter(near.i);document.querySelector('#field-notes')?.scrollIntoView({behavior:'smooth',block:'nearest'});return;}
 let best={d:Infinity,x:state.player.x,z:state.player.y};for(let x=0;x<39;x++)for(let z=0;z<39;z++){
  const p=project(x,.13,z,currentMvp);if(p.visible){const d=Math.hypot(p.x-sx,p.y-sy);if(d<best.d)best={x,z,d};}
 }
 if(best.d<45){pointerGoal={x:best.x,z:best.z};state.travel=null;follow=true;overview=false;}
});
canvas3.addEventListener('wheel',ev=>{distance=Math.max(7,Math.min(73,distance+ev.deltaY*.023));overview=distance>38;ev.preventDefault();},{passive:false});
canvas3.addEventListener('pointercancel',()=>{drag=false;});
canvas3.addEventListener('keydown',()=>{follow=true;overview=false;pointerGoal=null;});
canvas3.addEventListener('contextmenu',ev=>ev.preventDefault());
document.getElementById('orbitReset').addEventListener('click',()=>{follow=true;overview=false;distance=23;yaw=-.85;pitch=.7;pointerGoal=null;canvas3.focus({preventScroll:true});});
document.getElementById('mapOverview').addEventListener('click',()=>{overview=true;follow=true;distance=70;pitch=1.18;canvas3.focus({preventScroll:true});});
document.getElementById('voxelZoomIn').addEventListener('click',()=>{distance=Math.max(7,distance-5);overview=distance>38;});
document.getElementById('voxelZoomOut').addEventListener('click',()=>{distance=Math.min(73,distance+5);overview=distance>38;});
// Accessible live game and validation hooks; never give progression privileges to the WebGL view.
window.LatentAtlas3D={version:3,renderer:'WebGL volumetric pixel characters with real 3D surfaces + player sprite',get npcCount(){return chapters.length;},get voxelCharactersReady(){return voxelCast.ready;},get voxelCharacterVertices(){return voxelCast.vertexCount;},get vertexCount(){return totalVerts;},get currentChapter(){return state.current;},get camera(){return{yaw,pitch,distance,overview};},get spriteTexturesLoaded(){return Object.keys(texReady).filter(x=>texReady[x]);}};
requestAnimationFrame(updateWorld);
})();// end 3D renderer
