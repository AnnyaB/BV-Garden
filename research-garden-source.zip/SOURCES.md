# The Latent Atlas · primary research reading

These references support the concepts in the learning journey. They do **not** establish that open scientific problems have been fully solved or that a game quiz confers technical mastery. The map follows a conceptual prerequisite order rather than claiming a single universally correct history of the field.

- [Origins of AI — historical workshop archive](https://www.dartmouth.edu/~ai50/homepage)
- [Linear algebra — full open course](https://ocw.mit.edu/courses/18-06-linear-algebra-spring-2010/)
- [Deep Learning — Nature (2015)](https://www.nature.com/articles/nature14539)
- [A Simple Framework for Contrastive Learning of Visual Representations — ICML (2020)](https://proceedings.mlr.press/v119/chen20j.html)
- [A Tutorial on Energy-Based Learning (2006)](https://yann.lecun.org/exdb/publis/pdf/lecun-06.pdf)
- [Self-Supervised Learning from Images with a Joint-Embedding Predictive Architecture — CVPR (2023)](https://openaccess.thecvf.com/content/CVPR2023/html/Assran_Self-Supervised_Learning_From_Images_With_a_Joint-Embedding_Predictive_Architecture_CVPR_2023_paper.html)
- [V-JEPA 2: Self-Supervised Video Models Enable Understanding, Prediction and Planning (2025 preprint)](https://arxiv.org/abs/2506.09985)
- [Mastering Diverse Control Tasks Through World Models — Nature (2025)](https://www.nature.com/articles/s41586-025-08744-2)
- [World Models (2018 preprint)](https://worldmodels.github.io/)
- [TD-MPC2: Scalable, Robust World Models for Continuous Control — ICML (2024)](https://proceedings.mlr.press/v235/hansen24a.html)
- [Monte Carlo Tree Diffusion for System 2 Planning — ICML (2025)](https://proceedings.mlr.press/v267/yoon25a.html)
- [Dreamweaver — ICLR (2025)](https://proceedings.iclr.cc/paper_files/paper/2025/hash/ae82a60c5ce50b5c4d18cfe3214eb684-Abstract-Conference.html)
- [Safe Policy Improvement with Baseline Bootstrapping — ICML (2019)](https://proceedings.mlr.press/v97/laroche19a.html)
- [A Manifesto for Reproducible Science — Nature Human Behaviour (2017)](https://www.nature.com/articles/s41562-016-0021)
- [Preserving and combining knowledge in robotic lifelong reinforcement learning — Nature Machine Intelligence (2025)](https://www.nature.com/articles/s42256-025-00983-2)
- [International AI Safety Report (2026): limitations of long-term autonomous operation and forecasting](https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026)

**Accuracy notes:** I-JEPA is image-based representation learning; a JEPA architecture does not automatically produce a fully action-conditioned robot world model. MCTD combines diffusion-based planning with tree search; its published task results do not demonstrate universal physical-world planning. DreamerV3 demonstrates broad model-based reinforcement learning competence, not achieved general intelligence. The toy position/velocity system and energy function inside the game are explicitly hand-coded illustrations, not trained models.

**Art and rights:** Sprites are newly drawn pixel fan-art rather than extracted animation frames. The visually recognizable characters belong to their respective rights holders; this project is unofficial. Use of these likenesses on a public website may still need rights review or permission.

### Character-reference provenance (not sources of game image files)

- [SPY×FAMILY official anime cast page](https://spy-family.net/tvseries/)
- [Crunchyroll's SPY×FAMILY character guide](https://www.crunchyroll.com/news/guides/2024/4/18/spy-x-family-characters)
- [Anya figure and Mr. Chimera accessory — Bandai Tamashii Nations](https://tamashiiweb.com/item/14973/?wovn=en)

The character sprites are **not** official anime images downloaded from these pages. They are pixel fan-art drawn for this project; see [CAST_AUDIT.md](CAST_AUDIT.md).

**Stage 20 boundary:** The final character represents *open-ended general intelligence* as an unachieved research aspiration. Some systems perform bounded lifelong learning or self-improvement, but this is not equivalent to indefinite reliable self-improvement, AGI, ASI, or scientifically defined “beyond intelligence.”
