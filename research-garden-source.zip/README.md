# The Latent Atlas · Research Garden (fixed pixel-map edition)

The **interactive 2.5D pixel-art garden is the default and only active renderer**. This deliberately matches the clean, readable garden screenshot, rather than the cluttered GPU/WebGL overhead view. All 20 chapters, sprites, movement, science activities, Stella Stars, Tonitrus Bolts, quizzes and the Imperial Scholar exam are retained. The older experimental WebGL source file is included only for reference; it is **not loaded**.

## How to run

**Simplest:** download `The_Latent_Atlas_Research_Garden_Playable.html` from Google Drive and double-click it. Open with Chrome, Safari, Firefox or Edge. It is a standalone HTML file with 24 embedded pixel assets and no external dependencies. Google Drive's preview does **not** execute HTML games; the file must open in a browser or on a static website.

**For GitHub Pages:** extract `The_Latent_Atlas_Research_Garden_GitHub.zip` into a repository, keeping `index.html`, `.js`, `style.css` and `assets/` at root. Enable Settings → Pages → Deploy from branch → main → / (root). Then use the published `github.io` URL. The multi-file version and standalone should show the **same** 2.5D map.

**Controls:** click the map or characters, arrow keys/WASD or on-screen arrow buttons to walk, use the chapter journal to answer research questions. Complete one chapter to unlock only the next. Questions and award rules are documented in `GAME_RULES.md`.

## Scientific and artistic limitations

The learning game is an interactive conceptual exercise, not a research breakthrough or evidence of AGI. The pixel character sprites are *unofficial original fan-art interpretations*, not copied anime frames or official 3D models. The garden is a 2.5D isometric Canvas world; there is **no free-orbit 3D camera in this fixed edition**.
