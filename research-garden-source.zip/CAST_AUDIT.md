# Character asset audit (20 playable stages)

Sprites are **new pixel interpretations**, not exact or officially licensed images. Each chapter has precisely one distinct character or canonical in-universe creature; no generic human placeholders appear in the chapter ID sequence. Mr. Chimera is Anya's *stuffed toy* (not a human character), included because specifically requested.

| Level | Identity used as visual guide | Asset | Displayed scientific title |
|---:|---|---|---|
| 01 | Anya Forger | `assets/anya.png` | AI Origins |
| 02 | Bond Forger | `assets/bond.png` | Logic & Data |
| 03 | Mr. Chimera (plush) | `assets/chimera.png` | Python & Algorithms |
| 04 | Becky Blackbell | `assets/becky.png` | Mathematics |
| 05 | Damian Desmond | `assets/damian.png` | Optimization |
| 06 | Emile Elman | `assets/emile.png` | Machine Learning |
| 07 | Ewen Egeburg | `assets/ewen.png` | Deep Learning |
| 08 | Henry Henderson | `assets/henry.png` | Self-Supervision |
| 09 | Franky Franklin | `assets/franky.png` | Representations |
| 10 | Yuri Briar | `assets/yuri.png` | Energy Models |
| 11 | Sylvia Sherwood | `assets/sylvia.png` | Predictive Embeddings |
| 12 | Fiona Frost / Nightfall | `assets/fiona.png` | Dynamics & State |
| 13 | Martha Marriott | `assets/martha.png` | World Models |
| 14 | Melinda Desmond | `assets/melinda.png` | Model Predictive Control |
| 15 | Donovan Desmond | `assets/donovan.png` | Search & MCTD |
| 16 | Demetrius Desmond | `assets/demetrius.png` | Object & Skill Models |
| 17 | Camilla | `assets/camilla.png` | Embodied Learning |
| 18 | The Shopkeeper | `assets/shopkeeper.png` | Safety & Shift |
| 19 | Yor Forger | `assets/yor.png` | Physical Reasoning |
| 20 | Loid Forger | `assets/loid.png` | Open-Ended Intelligence (theoretical) |

Only this list of **20 selected** figures is represented; the complete series contains many more characters. The character identities are not used as the names of scientific chapters in the website's interface.

Verification sources for identities: [Official television series cast](https://spy-family.net/tvseries/), [Crunchyroll's series character guide](https://www.crunchyroll.com/news/guides/2024/4/18/spy-x-family-characters), [Bandai's Anya/Mr. Chimera figure listing](https://tamashiiweb.com/item/14973/?wovn=en).

Art provenance: the original four principal character illustrations were preserved from the previous generated prototype. Fifteen individually authored supporting figures plus the Mr. Chimera plush are drawn as differentiated pixel art from character-specific palettes, hair shapes, outfits, and accessories. The fixed edition draws the original RGBA pixel sprites in its 2.5D isometric Canvas world; the previous low-detail shared body template is no longer the delivered sprite source. The blue-sweater explorer retains the provided visual reference's black hair and clothing. Art fidelity is subjective; these are not frame-perfect copies or official licensed sprites.

## v5 asset verification

The four original principal sprites (Anya, Bond, Yor, Loid) and blue-sweater explorer have not been changed in this character upgrade. All other 16 sprites have been redesigned as distinct fan-art interpretations at 96×150 pixels, and are drawn as pixel sprites within the fixed 2.5D garden. This is not a claim of 100% frame-identical official anime art, official character licensing, skeletal animation, or fully sculpted 3D models.

## v6: detail-matched supporting character artwork

The original 4 lead characters and supplied blue-sweater explorer remain unchanged. The 16 other characters were replaced with unique, individually rendered pixel-art fan illustrations (not emojis, block placeholders, reused silhouettes, or downloaded copyrighted animation frames). Each has distinct visual identifiers and RGBA transparency. The generated 4×4 source sprite sheet is in `artwork_sources/supporting_cast_4x4.png`. Sylvia’s and the Shopkeeper’s sources included faux checkerboard transparency, which was cleaned in their exported sprites.

The intended 20-character identity order is only given in this developer art audit; chapter labels remain scientific concepts. These sprites are fan-art interpretations, not frame-perfect official art or rights-cleared commercial assets. The final concept is the hypothetical frontier of open-ended AGI/ASI, not achieved scientific invention.
