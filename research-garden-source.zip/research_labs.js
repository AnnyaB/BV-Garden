/* Twenty small, scientifically identified exercises. Calculations are transparent deterministic toys,
   NOT trained models, benchmark results, proof of mastery or original inventions. */
(()=>{
'use strict';
const LABS=[
['Four milestones','Explore dates in AI history. These are historical landmarks, not a complete history.',[['1956 · Dartmouth','1956'],['1986 · backpropagation','1986'],['2012 · deep vision','2012'],['2023 · predictive embeddings','2023']]],
['Boolean circuits','Toggle two binary inputs and see why the choice of operator changes the result.',[['Toggle A','a'],['Toggle B','b'],['Reset','reset']]],
['Search the graph','Follow breadth-first search on an unweighted directed graph from A toward F.',[['Advance BFS','step'],['Reset','reset']]],
['Check a derivative','Compare finite-difference estimates to the analytic derivative of f(x)=x² at x=3.',[['h = 1','1'],['h = 0.1','.1'],['h = 0.01','.01']]],
['Optimize a scalar','Use true gradient descent on L(w)=(w−2)², starting at w=6.',[['Step η=.1','.1'],['Step η=.3','.3'],['Step η=1.2','1.2'],['Reset','reset']]],
['Generalization under shift','Compare performance on two explicitly synthetic 20-sample test sets.',[['In-distribution','id'],['Shifted inputs','ood'],['Compare','both']]],
['Activation functions','Apply different nonlinear functions to exactly the same scalar input.',[['ReLU(−2)','relu'],['tanh(−2)','tanh'],['sigmoid(−2)','sigmoid'],['ReLU(+2)','positive']]],
['Contrastive temperature','Compute a two-candidate InfoNCE-style softmax loss: similarities 0.8 and 0.4.',[['τ = 0.1','.1'],['τ = 0.5','.5'],['τ = 1','1']]],
['State ambiguity','Two hidden velocities can produce the same observed position; predict the next position.',[['Observe position only','obs'],['Reveal velocities','reveal'],['Take Δt=1','step']]],
['Energy minimization','The energy surface above scores candidate states, not normalized probabilities.',[['E(−1)','-1'],['E(0)','0'],['E(2)','2'],['E(3)','3']]],
['Latent prediction','Calculate squared Euclidean error between an illustrative target embedding (2,1) and a candidate prediction.',[['Predict (0,1)','0'],['Predict (1,1)','1'],['Predict (2,1)','2']]],
['Transition model','Use the state-transition toy above; actions are hand-coded, not learned.',[['Show transition rule','rule'],['Show accumulated step','iterate']]],
['Rollout drift','Compare xₜ₊₁=xₜ+1 (reference) to a model predicting x̂ₜ₊₁=x̂ₜ+1.12.',[['Roll 1 step','1'],['Roll 5 steps','5'],['Roll 10 steps','10']]],
['Receding-horizon control','Compare constant actions over 3 steps with terminal cost (x₃−2)² and control penalty 0.1Σa².',[['a = −1','-1'],['a = 0','0'],['a = +1','1']]],
['Search exploration bonus','Compute UCB = mean + c√(ln N/n), where N=12 and two candidates have different visit counts.',[['Exploration c=.5','.5'],['Exploration c=1.4','1.4']]],
['Contact and inertia','Toy one-step Δv=FΔt/m with F=10 N, Δt=0.1 s; ignores friction.',[['Mass 1 kg','1'],['Mass 5 kg','5']]],
['Grasp feasibility','Compare frictional holding capacity μN with gravitational load mg (N=10 N, m=.5 kg, g=9.81 m/s²).',[['μ = 0.3','.3'],['μ = 0.8','.8']]],
['Abstention trade-off','Apply an illustrative risk threshold to five synthetic predictions; lower thresholds reject more actions.',[['Risk cutoff .2','.2'],['Risk cutoff .5','.5'],['Risk cutoff .8','.8']]],
['Active system identification','Compare passive observation with a controlled 3 N, 1 s push on objects of 1 kg and 3 kg.',[['Only observe','passive'],['Apply controlled push','push']]],
['Open-ended intelligence claim audit','Distinguish bounded empirical progress from the still-unproven goal of unrestricted AGI, ASI or self-improving intelligence.',[['No baseline','none'],['One in-distribution seed','single'],['Matched baselines + multiple seeds + held-out OOD','rigorous']]]
];
const states={};
function init(i){if(!states[i])states[i]={a:0,b:1,w:6,queue:['A'],seen:['A'],k:0};return states[i];}
function safe(t){return String(t).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');}
window.microLabHTML=function(ch){const i=ch.index,L=LABS[i];if(!L)return'';return `<div class="micro-lab" data-lab-panel="${i}"><div class="micro-heading"><span>◈ WORKSHOP / ${String(i+1).padStart(2,'0')}</span><small>Executable learning toy · no trained model</small></div><h5>${L[0]}</h5><p>${L[1]}</p><div class="micro-actions">${L[2].map(([name,key])=>`<button type="button" data-lab-step="${i}|${key}">${name}</button>`).join('')}</div><output class="micro-output" id="lab-output-${i}">Select an action to inspect the result.</output></div>`;};
function run(i,key){const s=init(i);let out='';
 switch(i){
 case 0:out=({'1956':'1956: The Dartmouth summer workshop helped establish artificial intelligence as a field.','1986':'1986: Influential backpropagation work accelerated multilayer neural-network learning.','2012':'2012: Deep CNNs dramatically improved large-scale ImageNet classification.','2023':'2023: I-JEPA presented predictive representation learning for images (CVPR).'})[key];break;
 case 1:if(key==='reset'){s.a=0;s.b=1;}if(key==='a')s.a=1-s.a;if(key==='b')s.b=1-s.b;out=`A=${s.a}, B=${s.b}; AND=${s.a&s.b}, XOR=${s.a^s.b}, OR=${s.a|s.b}. An operator is a specified truth table.`;break;
 case 2:{const edges={A:['B','C'],B:['D'],C:['E'],D:['F'],E:['F'],F:[]};if(key==='reset'){s.queue=['A'];s.seen=['A'];s.k=0;out='BFS reset: frontier [A].';break;}const n=s.queue.shift();if(!n){out='Queue empty. Visited '+s.seen.join(' → ');break;}for(const v of edges[n])if(!s.seen.includes(v)){s.seen.push(v);s.queue.push(v);}s.k++;out=`Expanded ${n}. Seen: ${s.seen.join(' → ')}. Queue: [${s.queue.join(', ')}]. ${n==='F'?'Goal reached.':''}`;break;}
 case 3:{const h=Number(key),est=((3+h)**2-9)/h;out=`f(3)=9, finite difference=${est.toFixed(4)}; analytic f′(3)=6; absolute error=${Math.abs(est-6).toFixed(4)}.`;break;}
 case 4:if(key==='reset'){s.w=6;out='Reset to w=6, L=16.';break;}const eta=+key,grad=2*(s.w-2);s.w-=eta*grad;out=`η=${eta}, previous gradient=${grad.toFixed(3)}, new w=${s.w.toFixed(3)}, new loss=${((s.w-2)**2).toFixed(3)}. Overshoot is possible.`;break;
 case 5:out=key==='id'?'Synthetic ID set: 17/20 correct = 85%.':key==='ood'?'Synthetic shifted set: 11/20 correct = 55%.':'Synthetic example: ID 85%, shifted 55%, gap 30 percentage points. NOT a measured research result.';break;
 case 6:{let v=key==='positive'?2:-2;const t=key==='relu'||key==='positive'?Math.max(v,0):key==='tanh'?Math.tanh(v):1/(1+Math.exp(-v));out=`input=${v}; ${key==='positive'?'ReLU':key==='relu'?'ReLU':key==='tanh'?'tanh':'sigmoid'} output=${t.toFixed(5)}.`;break;}
 case 7:{let temp=+key,p=Math.exp(.8/temp)/(Math.exp(.8/temp)+Math.exp(.4/temp));out=`τ=${temp}; P(positive candidate | two-candidate toy)=${p.toFixed(4)}, loss=−log(P)=${(-Math.log(p)).toFixed(4)}. No encoder was trained.`;break;}
 case 8:out=key==='obs'?'Both particles are at x=0 now. Position alone cannot identify velocity.':key==='reveal'?'Latent hypotheses: A has v=+1 m/s; B has v=−1 m/s.':'With Δt=1 s and no acceleration: x_next(A)=+1 m; x_next(B)=−1 m. Same current observation, different future.';break;
 case 9:{const x=+key;out=`Candidate s=${x}, E(s)=(s−2)²+0.4=${((x-2)**2+.4).toFixed(2)}. Lowest sampled energy wins.`;break;}
 case 10:{const v=+key;out=`Predict (${v},1) against target (2,1): squared L₂ error=${((v-2)**2).toFixed(2)}. These are fixed toy vectors, not JEPA predictions.`;break;}
 case 11:out=key==='rule'?'Rule: v′=clip(v+a,−3,3); x′=x+v′ (Δt=1). The transition is hand-coded.':'Multi-step forecasts compound transition error if a learned rule deviates from physical reality.';break;
 case 12:{const n=+key;out=`After ${n} steps from x₀=0: reference x=${n.toFixed(2)}, predicted x̂=${(1.12*n).toFixed(2)}, absolute rollout error=${(.12*n).toFixed(2)}.`;break;}
 case 13:{const a=+key;const x=3*a,loss=(x-2)**2+.1*3*a*a;out=`Constant a=${a}, terminal x₃=${x}, cost=${loss.toFixed(2)}. This toy enumerates only three actions; real MPC replans.`;break;}
 case 14:{const c=+key,N=12;const A=.6+c*Math.sqrt(Math.log(N)/10),B=.45+c*Math.sqrt(Math.log(N)/2);out=`c=${c}: UCB(A)=${A.toFixed(3)} (10 visits), UCB(B)=${B.toFixed(3)} (2 visits). Select ${A>B?'A':'B'} in this toy.`;break;}
 case 15:{const m=+key;out=`F=10 N, m=${m} kg, Δt=.1 s → Δv=${(10*.1/m).toFixed(2)} m/s. Actual contact adds friction and other constraints.`;break;}
 case 16:{const mu=+key,cap=mu*10,need=.5*9.81;out=`μ=${mu}; holding capacity=${cap.toFixed(2)} N, gravitational load=${need.toFixed(3)} N → ${cap>=need?'idealized static hold feasible':'idealized static hold infeasible'}. Real grasps need more modeling.`;break;}
 case 17:{const lim=+key,risks=[.05,.17,.29,.48,.75],unsafe=[false,true,false,true,true];let num=0,bad=0;risks.forEach((r,j)=>{if(r<=lim){num++;bad+=unsafe[j]?1:0;}});out=`Cutoff ${lim}: accepted ${num}/5 (${(100*num/5).toFixed(0)}% coverage), unsafe accepted ${bad}/${num}. All cases are explicitly synthetic, not validated risk estimates.`;break;}
 case 18:out=key==='passive'?'Both objects remain still; no acceleration is observed, so passive data do not distinguish mass.':'With a 3 N push for 1 s, Δv=3 m/s if mass=1 kg; Δv=1 m/s if mass=3 kg (friction ignored). A controlled intervention distinguishes them.';break;
 case 19:out=key==='none'?'An algorithm name with no matched baseline provides no comparative evidence.':key==='single'?'One seed on familiar tasks cannot establish robust OOD generalization or novelty.':'A bounded protocol: measure retention, OOD transfer, independent task-family adaptation, intervention safety and full compute costs across matched baselines and independent seeds. This could test a specific claim; it would NOT establish unrestricted AGI, ASI or perpetual recursive improvement.';break;
 }
 return out||'No calculation available.';
}
document.addEventListener('click',ev=>{const b=ev.target.closest('[data-lab-step]');if(!b)return;const [i,key]=b.dataset.labStep.split('|');const index=+i;const out=document.getElementById('lab-output-'+index);if(out)out.textContent=run(index,key);});
window.LatentAtlasLabs={count:LABS.length,labNames:LABS.map(x=>x[0])};
})();
