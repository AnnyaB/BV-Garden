# Stella Quest · exact scoring specification (v7)

This is the playable, browser-based research garden. The artwork consists of independent, unofficial pixel fan-art interpretations; the academy terminology is inspired by *SPY×FAMILY* and not affiliated with the rights holders.

## One connected research path

All 20 chapters must be visited in order. The first is AI Origins (pink-haired academy child), the second Logic & Data (white dog), the penultimate Physical Reasoning (dark-haired woman), and the final Open-Ended Intelligence (blond suited man). The final chapter concerns **theoretical frontiers**, not a claim that AGI, ASI, or beyond-intelligence already exists.

The explorer can walk with WASD or arrows, choose a map point, and tap houses or companions. A player cannot enter the immediate vicinity of a **future locked cottage**: the Tonitrus markers on the golden path represent the obstacle gates. Walking to a gate alone does not unlock a lesson; the chapter question challenge must be passed.

## Chapter assessment rules

Every chapter presents exactly **four one-shot questions**:

- Question 1: easy (conceptual prerequisite)
- Question 2: medium (apply the concepts)
- Question 3: difficult (scientific failure or research reasoning)
- Question 4: difficult (scientific failure or research reasoning)

Levels **1–5** use exactly one correct option per question. Levels **6–20** use multiple-select, requiring all correct selections and no incorrect selections. The graded response becomes final when **Lock answer** is pressed.

- **3 or 4 correct:** unlock next chapter and award its **one Stella Star**.
- **Exactly 2 correct, and both are the hard questions:** unlock next chapter but **do not** award a Stella. Replay with unused questions to earn it.
- **Any other outcome:** chapter remains locked until a new round is passed.
- **Every incorrect question:** +1 Tonitrus Bolt.
- **11th Bolt:** restart at chapter 1, resetting progress, stars, and bolts to 0. Used-question IDs are retained.

The user must earn **all 20 individual chapter Stellas** before the Imperial Scholar examination opens; completing all chapters without stars is insufficient.

## Imperial Scholar exam

The qualifier consists of 10 questions, in order: **2 easy, 3 medium, 5 hard**. The exam passes if **at least 9/10 answers and at least 4/5 hard answers** are correct. Every incorrect final-exam question also incurs a Tonitrus Bolt. Passing unlocks the separate scholar outfit sprite: an Eden-inspired academy uniform with a black cape, dark-red lining, and gold fastening. The regular blue-sweater explorer is left untouched.

## Why these are credible challenges, not a fake benchmark

The 20 chapter banks contain **240 individually authored, scientifically motivated questions** (3 easy, 3 medium, 6 hard per chapter) and 20 additional final-exam questions (4 easy, 6 medium, 10 hard). Options are shuffled, and a selected question ID is retired as soon as it is drawn. Ordinary page refresh does not reroll an active round. After the round finishes, a debrief reveals correct selections and explanatory notes; the same question cannot be drawn again within that save history.

**Finite bank limitation:** The local game cannot provide an infinite supply of genuinely novel research questions. Each chapter bank supports **up to three complete attempts** before its easy/medium pool is exhausted (assuming other questions have not been seen), and the final exam supports up to two attempts. The game **fails closed** rather than secretly recycling questions. Extend `quiz_bank.js` with new, reviewed items to allow further attempts.

**Not tamper-proof:** This is client-side educational software. Its answers and localStorage are inspectable, and a sufficiently motivated player can modify them. An anti-cheat guarantee would require a trusted server and an independently maintained unseen question set, contrary to the offline/no-cost GitHub Pages deployment goal.

**Scientific limitation:** Passing these conceptual assessments does not demonstrate scientific research competence, invented SOTA methods, or general intelligence. The 2.5D pixel garden, mini simulations, and chapter exercises teach principles and point to real papers, but do not themselves train or verify novel world models. This fixed edition always uses the interactive 2.5D isometric Canvas renderer so it matches the approved garden appearance, regardless of WebGL support.

## Anime-versus-game rules

Eden Academy's fictional requirements in the original story are **8 Stella Stars** for Imperial Scholar status and **8 Tonitrus Bolts** for expulsion. **20 Stars and 11 Bolts** are custom rules chosen by the creator for this 20-chapter research game; they are not asserted as canonical.

References: [Crunchyroll's anime guide](https://www.crunchyroll.com/hi/news/guides/2023/10/5/what-to-know-before-spy-family-season-2), [Imperial Scholar uniform summary](https://spy-x-family.fandom.com/wiki/Imperial_Scholars), [Source research list](SOURCES.md).
