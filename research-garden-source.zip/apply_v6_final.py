from pathlib import Path
from PIL import Image
import numpy as np
root=Path(__file__).parent
# Only update the supplemental 16 artwork assets; leave five original sprites untouched.
syl=root/'assets/sylvia.png'
im=Image.open(syl).convert('RGBA')
a=np.array(im)
H,W=a.shape[:2]
yy,xx=np.mgrid[:H,:W]
colors=a[:,:,:3].astype(int)
span=colors.max(2)-colors.min(2)
# The generated source sheet embedded a checked transparency preview *inside*
# Sylvia's top-right/background. Remove its neutral light checker tiles only.
checker=(xx>=76)&(yy>=39)&(colors.min(2)>=195)&(span<=11)
# Exclude outline/hair/facial colors (saturated or dark) automatically.
a[checker,3]=0
Image.fromarray(a).save(syl)

p=root/'game.js';s=p.read_text()
s=s.replace("  reproducible:'https://www.nature.com/articles/s41562-016-0021'", "  reproducible:'https://www.nature.com/articles/s41562-016-0021',\n  lifelong:'https://www.nature.com/articles/s42256-025-00983-2'")
old="  ['Scientific Invention','Falsifiable hypotheses · general intelligence research','What has not yet been demonstrated?','Map prior art and its assumptions; formulate a genuinely discriminating hypothesis; prove conditional properties where possible; use matched baselines, independent seeds, uncertainty intervals, ablations, reproducible code and external OOD evaluation. AGI/ASI remain research aspirations, not achieved results.','gap → hypothesis → experiment → falsification','Create a minimal reproducible failure benchmark; submit a protocol, competing baselines, negative results and clearly scoped claims before naming a new method.','Could an embodied learner recognize its own inadequate model and expand predictive competence safely within fixed compute?','Open scientific reproducibility',LINKS.reproducible,'Novelty and reliability require comparative evidence.','An acronym proves a new scientific invention.','One benchmark win establishes general intelligence.','invent']"
new="  ['Open-Ended Intelligence','THEORETICAL FRONTIER · AGI → ASI · no demonstrated general solution','Could an intelligent system keep learning beyond its training world?','Study open-ended learning, continual adaptation, world-model revision, durable memory, transfer across unfamiliar tasks, safe autonomous experimentation, and the hypothesis of recursive self-improvement. Bounded improvements have been demonstrated in specific settings, but unrestricted open-ended AGI, ASI, and beyond-intelligence are not empirically established. No existing benchmark result alone demonstrates them.','experience → revised model → new tasks → independent evaluation','Specify one falsifiable, compute-bounded lifelong-learning experiment. Compare adaptive versus frozen systems on disjoint task families; measure retention, unanticipated OOD transfer, intervention safety, failure detection and total resource costs across seeds. Do not claim that doing the experiment creates AGI.','Can an embodied learner discover when its predictive model is inadequate, acquire new skills without catastrophic forgetting, and sustain independent progress on genuinely novel tasks safely?','Lifelong robotic learning · Nature Machine Intelligence 2025',LINKS.lifelong,'Open-ended general intelligence remains a hypothesis requiring robust evidence across unseen tasks and time.','Passing this fictional game establishes artificial superintelligence.','One benchmark score proves unrestricted recursive self-improvement.','frontier']"
if old not in s: raise Exception('Cannot find exact final stage')
s=s.replace(old,new)
s=s.replace('through predictive representation learning, MCTD, physical interaction and research invention.', 'through predictive representation learning, MCTD, physical interaction and the theoretical frontier of open-ended general intelligence.')
s=s.replace('Turn one unresolved hypothesis into an independently reproducible experiment.', 'Treat AGI, ASI and unrestricted self-improvement as hypothetical goals; turn a bounded open problem into a reproducible experiment.')
p.write_text(s)

lab=root/'research_labs.js';s=lab.read_text()
s=s.replace("['Scientific claim audit','Select what evidence actually supports a new scientific method; never mistake a game milestone for discovery.'", "['Open-ended intelligence claim audit','Distinguish bounded empirical progress from the still-unproven goal of unrestricted AGI, ASI or self-improving intelligence.'")
s=s.replace("'A stronger protocol: audit prior art; predefine claims; compare matched baselines; run multiple independent seeds; evaluate held-out OOD, ablations, and failure cases; publish code and limitations. This is a plan, not evidence the method works.'", "'A bounded protocol: measure retention, OOD transfer, independent task-family adaptation, intervention safety and full compute costs across matched baselines and independent seeds. This could test a specific claim; it would NOT establish unrestricted AGI, ASI or perpetual recursive improvement.'")
lab.write_text(s)

notes=root/'SOURCES.md';s=notes.read_text()
needle='- [A Manifesto for Reproducible Science — Nature Human Behaviour (2017)](https://www.nature.com/articles/s41562-016-0021)'
s=s.replace(needle,needle+'\n- [Preserving and combining knowledge in robotic lifelong reinforcement learning — Nature Machine Intelligence (2025)](https://www.nature.com/articles/s42256-025-00983-2)\n- [International AI Safety Report (2026): limitations of long-term autonomous operation and forecasting](https://internationalaisafetyreport.org/publication/international-ai-safety-report-2026)')
s+='\n**Stage 20 boundary:** The final character represents *open-ended general intelligence* as an unachieved research aspiration. Some systems perform bounded lifelong learning or self-improvement, but this is not equivalent to indefinite reliable self-improvement, AGI, ASI, or scientifically defined “beyond intelligence.”\n'
notes.write_text(s)

cast=root/'CAST_AUDIT.md';s=cast.read_text().replace('Scientific Invention |', 'Open-Ended Intelligence (theoretical) |')
s+='\n## v6: detail-matched supporting character artwork\n\nThe original 4 lead characters and supplied blue-sweater explorer remain unchanged. The 16 other characters were replaced with unique, individually rendered pixel-art fan illustrations (not emojis, block placeholders, reused silhouettes, or downloaded copyrighted animation frames). Each has distinct visual identifiers and RGBA transparency. The generated 4×4 source sprite sheet is in `artwork_sources/supporting_cast_4x4.png`. Sylvia’s source included faux checkerboard transparency, which was cleaned in the exported sprite.\n\nThe intended 20-character identity order is only given in this developer art audit; chapter labels remain scientific concepts. These sprites are fan-art interpretations, not frame-perfect official art or rights-cleared commercial assets. The final concept is the hypothetical frontier of open-ended AGI/ASI, not achieved scientific invention.\n'
cast.write_text(s)
readme=root/'README.md';s=readme.read_text()
s=s.replace('Scientific Invention', 'Open-Ended Intelligence (theoretical)')
s+='\n### Supporting-character art upgrade (v6)\n\nThe original 4 lead sprites and the blue-sweater player remain unchanged. Sixteen supporting characters have distinct pixel illustrations, rather than emojis or rectangle placeholders. The 4×4 editable source atlas is retained in `artwork_sources/`. Stage 20 is a clearly labeled theoretical frontier, *not* a claim that AGI/ASI or indefinitely accelerating self-improvement exists.\n'
readme.write_text(s)
print('Patched Sylvia image and final conceptual chapter; original four/player not modified')
