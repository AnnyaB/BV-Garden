from PIL import Image,ImageDraw
from pathlib import Path
import math
ROOT=Path(__file__).parent/'assets'
S=5

def scaled(icon, size=40):
 return icon.resize((icon.width*S,icon.height*S),Image.Resampling.NEAREST)

def star():
 im=Image.new('RGBA',(32,34));d=ImageDraw.Draw(im)
 cx,cy=16,15
 def poly(r1,r2):
  return [(round(cx+math.cos(-math.pi/2+k*math.pi/5)*(r1 if k%2==0 else r2)),round(cy+math.sin(-math.pi/2+k*math.pi/5)*(r1 if k%2==0 else r2))) for k in range(10)]
 d.ellipse((6,24,26,32),fill='#65543c');d.rectangle((11,22,21,29),fill='#866744')
 d.polygon(poly(15,6),fill='#705029')
 d.polygon(poly(13,5),fill='#e6a944')
 d.polygon(poly(11,4),fill='#fff1a0')
 d.polygon([(16,5),(18,12),(25,12),(19,17),(20,24),(16,20)],fill='#f6c750')
 for x,y in [(12,9),(10,15),(14,7),(20,13)]:d.point((x,y),fill='#fffbe2')
 return scaled(im)

def bolt():
 im=Image.new('RGBA',(32,34));d=ImageDraw.Draw(im)
 # deep scarlet inset and black iron badge, golden lightning with tiered offset highlight
 d.rounded_rectangle((4,3,28,31),5,fill='#49333b',outline='#231e2f',width=2)
 d.rounded_rectangle((7,6,25,28),3,fill='#ab4a50',outline='#e48b65',width=1)
 pts=[(18,7),(10,19),(16,18),(13,27),(25,13),(18,14),(22,7)]
 d.polygon([(x+1,y+1) for x,y in pts],fill='#7d3e25')
 d.polygon(pts,fill='#f8cd66')
 d.line([(17,9),(13,17),(18,16)],fill='#fff7c7',width=2)
 return scaled(im)
star().save(ROOT/'stella.png');bolt().save(ROOT/'tonitrus.png')
# Imperial Scholar outfit is a newly drawn overlay inspired by the documented black cape, dark red lining and golden cord.
# Preserve explorer.png pixel-for-pixel as its own separate file.
base=Image.open(ROOT/'explorer.png').convert('RGBA').resize((180,204),Image.Resampling.NEAREST)
layer=Image.new('RGBA',base.size,(0,0,0,0));p=ImageDraw.Draw(layer)
# In this sprite head occupies x~68..107 y~8..75, torso y~65..132; cape over shoulders, behind arms
# Put cape behind the original sprite, preserving the character's face and hair.
p.polygon([(69,73),(57,81),(44,101),(37,142),(45,168),(70,161),(76,123),(92,113),(108,124),(120,163),(143,167),(151,144),(135,95),(117,80),(105,76)],fill='#1e202b')
p.polygon([(60,85),(46,103),(41,141),(49,160),(65,151),(72,111)],fill='#732c3c')
p.polygon([(116,82),(133,102),(146,142),(139,159),(122,148),(106,105)],fill='#7b3340')
p.line([(61,88),(43,133),(48,157)],fill='#4e4a54',width=4)
p.line([(128,87),(147,141),(139,164)],fill='#4e4a54',width=4)
# gold rope and clasp at neck, in front of player; overlay later
result=Image.alpha_composite(layer,base)
# Transform the BLUE sweater silhouette into an Eden-inspired dark formal uniform,
# while retaining the same explorer face and hair (the base sprite is not changed).
px=result.load()
for yy in range(75,160):
 for xx in range(38,148):
  r,g,b,a=px[xx,yy]
  if a>40 and b>r*1.23 and b>g*1.08 and b>75:
   lum=max(0,min(1,(r+g+b)/650))
   px[xx,yy]=(int(32+lum*30),int(37+lum*25),int(44+lum*24),a)
front=Image.new('RGBA',result.size);f=ImageDraw.Draw(front)
# Eden Academy dress/tunic, white collar, gold piping and short flared skirt.
f.polygon([(76,92),(90,94),(106,92),(113,133),(119,148),(65,148),(69,128)],fill='#292a32')
f.polygon([(80,91),(90,102),(86,105),(76,94)],fill='#f9ede4')
f.polygon([(102,91),(92,102),(96,105),(108,94)],fill='#f9ede4')
f.polygon([(89,103),(92,107),(96,103),(94,122),(89,122)],fill='#9c3647')
f.line([(75,94),(69,132),(65,147),(119,147),(113,128),(109,95)],fill='#c9a451',width=3)
f.line([(72,136),(115,136)],fill='#c8a85f',width=2)
f.line([(69,145),(116,145)],fill='#d5ad59',width=2)
# front cape edges dark red lined, outlined to read as a cape in a tiny voxel sprite
f.line([(67,86),(58,106),(50,151)],fill='#a8585b',width=3)
f.line([(116,85),(132,108),(141,151)],fill='#a8585b',width=3)

f.line([(78,92),(91,100),(105,91)],fill='#e8b95d',width=3)
f.ellipse((88,97,94,103),fill='#f6da8c',outline='#846c3f')
result=Image.alpha_composite(result,front)
result.resize((90,102),Image.Resampling.LANCZOS).save(ROOT/'explorer_scholar.png')
print('new artwork:',*(str(ROOT/x) for x in ['stella.png','tonitrus.png','explorer_scholar.png']))
